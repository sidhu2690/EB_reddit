#!/usr/bin/env python3
import numpy as np
from universal_descriptors import augment_profiles
import universal_model3 as um

profs = augment_profiles()
for p in profs:
    p["group"] = "Channel" if p["family"] in ("LM","UPM") else {"KTH":"TBL","Pipe":"Pipe","Cou":"Couette"}[p["family"]]

for held in ["Channel","Pipe","TBL","Couette"]:
    train = [p for p in profs if p["group"] != held]
    test = [p for p in profs if p["group"] == held]
    freeze = (held == "TBL")  # growth coefficients stay at physics prior (2/kappa^2 etc.)
    x, res = um.fit(train, freeze_growth=freeze)
    tr = um.evaluate(train, x); te = um.evaluate(test, x)
    print(f"\nHELD {held}  freeze_growth={freeze}")
    print("  params:", {n: round(float(v),4) for n,v in zip(um.PARAM_NAMES, x)})
    print(f"  train mean={np.mean(list(tr.values())):.5f} min={np.min(list(tr.values())):.5f}")
    print(f"  TEST  mean={np.mean(list(te.values())):.5f} min={np.min(list(te.values())):.5f}")
    for p in test:
        print(f"   {p['id']:10s} R2={te[p['id']]:.5f}")
