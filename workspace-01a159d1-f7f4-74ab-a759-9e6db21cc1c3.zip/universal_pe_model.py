#!/usr/bin/env python3
"""
ONE universal, physics-descriptor formula for P/eps in wall turbulence.
Same functional form and same frozen constants for plane channels, pipes,
zero-pressure-gradient turbulent boundary layers, and plane Couette flow.

Inputs (per profile; arrays over the wall-normal grid):
  yp     : y+                         (inner coordinate)
  eta    : y/delta                    (outer coordinate; delta = half-height,
                                       pipe radius, or delta_99 for a TBL)
  Re_tau : friction Reynolds number   (scalar)
  tau    : total stress (dU+/dy+ - <u'v'>+) / u_tau^2 profile.
           For parallel flows this is analytic: tau = 1 - alpha*eta with
           alpha = 1 (pressure-driven channel/pipe) or 0 (Couette).
           For a developing layer it is taken from the mean momentum balance.
  Vplus  : mean wall-normal velocity V+ profile (exactly 0 in parallel flows;
           nonzero only through streamwise development / entrainment).
  mgeo   : geometry exponent of the wall-normal divergence:
           0 = planar, 1 = axisymmetric (pipe).

Formula (frozen constants below; 14 shared fitted constants, no family branch):
  tau_p  = tau(y+ = 12)
  eps_pk = E0 * tau_p^rp
  p_peak = tau_p^2 / (4 eps_pk)                       [equal-stress peak]
  B      = F_in(y+; p_peak) + Ec(Re) * L(y+; sqrt(100 Re), w)
           Ec(Re) = Einf * (1 - sqrt(150/Re))_+       [log-layer crest]
  pe     = B * [tanh^2(a tau)/tanh^2(a)]               [stress wake]
             * [1 - cc tanh^2(y+/300) eta^2 tau^2]     [core import]
             * [1/(1 + m eta/4)]                        [axisymmetry]
             + G0 V+ (lnRe/ln1000)^rg eta^pg tanh^2(a tau^qg)   [growth]

Inner core:
  F_in = tanh^3(a1 y+ + a2 y+^2) * [1 - T^5(1-T^2) + c1 y+^2 e^{-bexp y+}],
  T = tanh(bwave y+), with c1 chosen so that max F_in = p_peak.

Validation (26 DNS profiles, turbulent domain eta <= 1.05):
  all-data frozen fit : mean R2 = 0.99540, min = 0.98095
  leave-one-family-out: Channel 0.99611, Pipe 0.99653, TBL 0.98874,
                        Couette 0.98726  (see universal_lofo4.py)
"""
import numpy as np

# Frozen shared constants (single all-data fit; see universal_model4.py)
A1, A2, BEXP, BWAVE = 0.160773, 0.00540632, 0.210307, 0.0195789
E0, RP = 0.140725, 2.42579
EINF, WBUMP = 0.119023, 0.456099
A_TAU, CC = 3.92809, 0.534588
G0, RG, PG, QG = 14.7805, 1.8693, 0.974179, 0.566203
LN1000 = np.log(1000.0)

def _F_in(yp, c1):
    yp = np.maximum(np.asarray(yp, dtype=float), 1e-12)
    Gg = np.tanh(A1 * yp + A2 * yp**2) ** 3
    T = np.tanh(BWAVE * yp)
    return Gg * (1.0 - T**5 * (1.0 - T**2) + c1 * yp**2 * np.exp(-BEXP * yp))

def _c1_for_peak(ppeak):
    ypg = np.linspace(8.0, 16.0, 400)
    lo, hi = 0.005, 0.5
    for _ in range(50):
        mid = 0.5 * (lo + hi)
        if _F_in(ypg, mid).max() < ppeak:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)

def tau_parallel(eta, alpha):
    """Exact total stress of a parallel flow: alpha=1 pressure-driven, 0 Couette."""
    return np.clip(1.0 - alpha * np.asarray(eta, dtype=float), 0.0, 1.0)

def predict_pe(yp, eta, Re_tau, tau, Vplus, mgeo):
    yp = np.asarray(yp, dtype=float)
    eta = np.asarray(eta, dtype=float)
    tau = np.clip(np.asarray(tau, dtype=float), 0.0, 1.0)
    Vplus = np.asarray(Vplus, dtype=float)
    o = np.argsort(eta)
    tau_p = float(np.interp(12.0 / Re_tau, eta[o], tau[o]))
    eps_pk = E0 * max(tau_p, 1e-9) ** RP
    p_peak = tau_p**2 / (4.0 * eps_pk)
    F0 = _F_in(yp, _c1_for_peak(p_peak))
    Ec = EINF * max(0.0, 1.0 - np.sqrt(150.0 / Re_tau))
    yc = np.sqrt(100.0 * Re_tau)
    L = np.exp(-0.5 * (np.log(np.maximum(yp, 1e-12) / yc) / WBUMP) ** 2)
    B = F0 + Ec * L
    eta_c = np.clip(eta, 0.0, 1.05)
    W_tau = np.tanh(A_TAU * tau) ** 2 / np.tanh(A_TAU) ** 2
    W_core = 1.0 - CC * np.tanh(yp / 300.0) ** 2 * eta_c**2 * tau**2
    W_geo = 1.0 / (1.0 + mgeo * eta_c / 4.0)
    G = (G0 * Vplus * (np.log(Re_tau) / LN1000) ** RG * eta_c**PG
         * np.tanh(A_TAU * tau**QG) ** 2)
    return B * W_tau * np.clip(W_core, 0.0, None) * W_geo + G

if __name__ == "__main__":
    from universal_descriptors import augment_profiles
    profs = augment_profiles()
    scores = {}
    print(f"{'id':10s} {'family':6s} {'Re_tau':>7s} {'R2 (eta<=1.05)':>14s} {'R2 (full raw)':>13s}")
    for p in profs:
        pred = predict_pe(p["yp"], p["eta"], p["re_tau"], p["tau"], p["Vmean"], p["mgeo"])
        row = []
        for eta_max in (1.05, np.inf):
            m = (p["eta"] <= eta_max) & (p["yp"] >= 0.05)
            pe = p["pe"]
            row.append(1 - np.sum((pred[m] - pe[m])**2) / np.sum((pe[m] - pe[m].mean())**2))
        scores[p["id"]] = row
        print(f"{p['id']:10s} {p['family']:6s} {p['re_tau']:7.0f} {row[0]:14.5f} {row[1]:13.5f}")
    for j, lab in [(0, "eta<=1.05"), (1, "full raw")]:
        v = np.array([s[j] for s in scores.values()])
        print(f"{lab}: mean={v.mean():.5f} median={np.median(v):.5f} min={v.min():.5f}")
