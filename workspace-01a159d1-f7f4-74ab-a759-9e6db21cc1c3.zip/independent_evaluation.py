"""
Independent (never-fitted) evaluation of the frozen universal P/eps formula
in universal_pe_model.py (U4).  NO constant is refitted here.

Every dataset below is outside the original 26 training profiles:
  A Hoyas/Oberlack channel Retau=10049 (TUdatalib) - Reynolds extrapolation x2
  B Bernardini-Pirozzoli-Orlandi channels 180..4000 (Newton/Rome database)
  C FDY Darmstadt plane Couette, direct-epsilon profiles Retau~132..553
  D FDY Darmstadt plane Couette Retau~2013 from component budgets
  E Yao (Texas Tech) pipe Retau=550 and 5200, TKE budgets (Dataverse)
  F Yao et al. open-channel Retau=2000 (eps approximated by enstrophy - flagged)
  G Kitsios et al. TBL DNS: ZPG (beta=0), mild APG (beta=1), strong APG (beta=39)
  H Avsarkisov et al. transpired Poiseuille flow (blowing side, local-wall scaling)
  I (appendix) Vinuesa et al. NACA4412 well-resolved LES stations (WingData)

Mask everywhere: y+ >= 0.05 and eta <= 1 (same as the frozen evaluation).
A diagnostic score with V+ set to zero (same frozen constants, NOT a refit)
is reported for the pressure-gradient / transpiration rows to isolate the
role of the growth term.  Outputs: independent_results.csv,
independent_profiles.pdf/.png
"""
import numpy as np, sys, os, glob, warnings
warnings.filterwarnings('ignore')
sys.path.insert(0, '/home/user')
from universal_pe_model import predict_pe
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

RES = []
PANELS = {}

def r2(pe, pred, m):
    m = m & np.isfinite(pe) & np.isfinite(pred)
    return 1 - np.sum((pred[m]-pe[m])**2) / np.sum((pe[m]-pe[m].mean())**2), int(m.sum())

def record(name, group, Re, yp, eta, pe, pred, pred_v0=None, note='', panel=None):
    m = (yp >= 0.05) & (eta <= 1.0)
    R, n = r2(pe, pred, m)
    pk = (yp > 1) & (yp < 40)
    row = dict(name=name, group=group, Retau=round(float(Re)), n=n, R2=round(R, 5),
               peak_DNS=round(float(np.nanmax(pe[pk])), 3) if pk.any() else np.nan,
               peak_pred=round(float(np.nanmax(pred[pk])), 3) if pk.any() else np.nan,
               R2_diag_V0=(round(r2(pe, pred_v0, m)[0], 5) if pred_v0 is not None else np.nan),
               note=note)
    RES.append(row)
    print(f"{name:34s} Retau={Re:6.0f} n={n:5d} R2={R:9.4f}  peak {row['peak_DNS']:.3f}/{row['peak_pred']:.3f}"
          + (f"  diagV0={row['R2_diag_V0']:.4f}" if pred_v0 is not None else ""))
    if panel:
        PANELS[panel] = (name, eta, pe, pred)

def load_num(path, mincols=2):
    rows = []
    for line in open(path, errors='ignore'):
        s = line.strip()
        if s and (s[0].isdigit() or s[0] in '-.'):
            try:
                v = [float(x) for x in s.split()]
                if len(v) >= mincols: rows.append(v)
            except ValueError:
                pass
    return np.array(rows)

ID = '/home/user/independent_data'

# ---------------------------------------------------------------- A channel 10049
uu = load_num(f'{ID}/channel10k/P10k.uu.txt'); vv = load_num(f'{ID}/channel10k/P10k.vv.txt')
ww = load_num(f'{ID}/channel10k/P10k.ww.txt'); mn = load_num(f'{ID}/channel10k/P10k.txt')
eta, yp = uu[:, 0], uu[:, 1]
Pk = 0.5*(uu[:, 3] + vv[:, 3] + ww[:, 3]); epsk = -0.5*(uu[:, 2] + vv[:, 2] + ww[:, 2])
Re = float(yp[-1]); pe = Pk/epsk
tau_meas = mn[:, 7] - mn[:, 6]            # S+ - uv+
pred_a = predict_pe(yp, eta, Re, np.clip(1-eta, 0, 1), np.zeros_like(yp), 0.0)
pred_m = predict_pe(yp, eta, Re, np.clip(tau_meas, 0, None), np.zeros_like(yp), 0.0)
record('Channel Hoyas/Oberlack 10049', 'A channel-Re-extrapolation', Re, yp, eta, pe, pred_a,
       note=f'measured-tau variant R2={r2(pe,pred_m,(yp>=0.05)&(eta<=1))[0]:.5f}', panel=(0, 0))

# ---------------------------------------------------------------- B BPO channels
for rt in [180, 550, 1000, 2000, 4000]:
    a = load_num(f'{ID}/pirozzoli_channel/kbudg{rt}.dat')
    y, yp = a[:, 0], a[:, 1]; P, eps = a[:, 2], -a[:, 6]
    Re = float(yp[-1]/y[-1]); eta = yp/Re; pe = P/eps
    pred = predict_pe(yp, eta, Re, np.clip(1-eta, 0, 1), np.zeros_like(yp), 0.0)
    record(f'Channel BPO {rt}', 'B channel-independent-code', Re, yp, eta, pe, pred)

# ---------------------------------------------------------------- C FDY Couette direct
for rt in [125, 180, 250, 550]:
    a = load_num(f'{ID}/fdy_couette/Couette_Retau{rt}_data.txt')
    lo = a[:, 0] <= 1.0; a = a[lo]
    eta, yp = a[:, 0], a[:, 1]
    P = -a[:, 9]*a[:, 16]; eps = a[:, 12]; pe = P/eps
    Re = float(np.interp(1.0, eta, yp))
    pred = predict_pe(yp, eta, Re, np.ones_like(yp), np.zeros_like(yp), 0.0)
    record(f'Couette FDY {rt}', 'C Couette-independent', Re, yp, eta, pe, pred,
           panel=(1, 0) if rt == 550 else None)

# ---------------------------------------------------------------- D FDY Couette 2000 budgets
uu = load_num(f'{ID}/fdy_couette/Cou2000.16pi6pi.uu.txt')
vv = load_num(f'{ID}/fdy_couette/Cou2000.16pi6pi.vv.txt')
ww = load_num(f'{ID}/fdy_couette/Cou2000.16pi6pi.ww.txt')
eta, yp = uu[:, 0], uu[:, 1]
Pk = 0.5*(uu[:, 3] + vv[:, 3] + ww[:, 3]); epsk = -0.5*(uu[:, 2] + vv[:, 2] + ww[:, 2])
lo = eta <= 1.0
Re = float(np.interp(1.0, eta, yp)); pe = (Pk/epsk)
pred = predict_pe(yp[lo], eta[lo], Re, np.ones(lo.sum()), np.zeros(lo.sum()), 0.0)
record('Couette FDY 2000 budgets', 'D Couette-Re-extrapolation', Re, yp[lo], eta[lo], pe[lo], pred, panel=(1, 1))

# ---------------------------------------------------------------- E Texas pipes
for f, nm in [('PIPE_Re550_RSTE_k.dat', 'Pipe Yao 550'), ('PIPE_Re5K_RSTE_k.dat', 'Pipe Yao 5200')]:
    a = np.loadtxt(f'{ID}/texas_pipe/{f}')
    eta, yp, P, eps = a[:, 1], a[:, 2], a[:, 3], -a[:, 8]; pe = P/eps
    Re = float(yp[-1]/eta[-1])
    pred = predict_pe(yp, eta, Re, np.clip(1-eta, 0, 1), np.zeros_like(yp), 1.0)
    record(nm, 'E pipe-independent', Re, yp, eta, pe, pred, panel=(0, 1) if '5200' in nm else None)

# ---------------------------------------------------------------- F open channel (eps~enstrophy)
a = load_num(f'{ID}/texas_openchannel/STAT_RE2000.dat')
y, yp, U, uv = a[:, 0], a[:, 1], a[:, 2], a[:, 6]
eps = a[:, 7]**2 + a[:, 8]**2 + a[:, 9]**2
eta = y/y.max(); Re = float(yp.max()); pe = (-uv*np.gradient(U, yp))/eps
pred = predict_pe(yp, eta, Re, np.clip(1-eta, 0, 1), np.zeros_like(yp), 0.0)
record('Open channel Yao 2000', 'F NEW CLASS open channel', Re, yp, eta, pe, pred,
       note='eps approximated by enstrophy (no budget file published)', panel=(0, 2))

# ---------------------------------------------------------------- G Kitsios TBLs
NU_K = 0.000285714
def kitsios(f, name, group, panel=None):
    a = np.loadtxt(f, delimiter=',', skiprows=1)
    y, U, V, uv, P, eps = a.T
    ut = np.sqrt(NU_K*U[1]/y[1]); Ue = U[-1]; d99 = np.interp(0.99*Ue, U, y)
    yp = y*ut/NU_K; eta = y/d99; Re = d99*ut/NU_K
    tau = (NU_K*np.gradient(U, y) - uv)/ut**2
    pe = P/eps; Vp = V/ut
    pred = predict_pe(yp, eta, Re, np.clip(tau, 0, None), Vp, 0.0)
    pred0 = predict_pe(yp, eta, Re, np.clip(tau, 0, None), np.zeros_like(yp), 0.0)
    record(name, group, Re, yp, eta, pe, pred, pred_v0=pred0, panel=panel)

for f in sorted(glob.glob(f'{ID}/kitsios_apg/ZPG_Beta0_*.csv')):
    tag = os.path.basename(f).replace('ZPG_Beta0_', '').replace('.csv', '')
    kitsios(f, f'TBL Kitsios ZPG beta=0 ({tag})', 'G TBL-independent-ZPG',
            panel=(1, 2) if 'st1393' in f else None)
for f in sorted(glob.glob(f'{ID}/kitsios_apg/mildAPG_Beta1_*.csv')):
    tag = os.path.basename(f).replace('mildAPG_Beta1_', '').replace('.csv', '')
    kitsios(f, f'TBL Kitsios APG beta=1 ({tag})', 'G NEW PHYSICS mild APG',
            panel=(2, 0) if 'st290' in f else None)
for f in sorted(glob.glob(f'{ID}/kitsios_apg/strongAPG_Beta39_*.csv')):
    tag = os.path.basename(f).replace('strongAPG_Beta39_', '').replace('.csv', '')
    kitsios(f, f'TBL Kitsios APG beta=39 ({tag})', 'G NEW PHYSICS strong APG',
            panel=(2, 1) if 'st500' in f else None)

# ---------------------------------------------------------------- H transpired Poiseuille (blowing side)
UB = 0.8987
for fn, utau, v0Uw, nm in [('Poiseuille_Re250_005.txt', 0.0519, 0.003, 'Transpired chan. 250 v0+=.05'),
                           ('Poiseuille_Re480_010.txt', 0.0625, 0.0075, 'Transpired chan. 480 v0+=.11'),
                           ('Poiseuille_Re850_005.txt', 0.0450, 0.0026, 'Transpired chan. 850 v0+=.05')]:
    a = load_num(f'{ID}/fdy_transpiration/{fn}')
    yh, yp, uv, dU = a[:, 0], a[:, 1], a[:, 9], a[:, 16]
    eps = a[:, 6]**2 + a[:, 7]**2 + a[:, 8]**2     # FDY dissipation = enstrophy (their eps column is mis-normalised)
    pe = (-uv*dU)/eps; tau_avg = dU - uv
    Re_avg = yp[-1]/2; v0p = v0Uw*UB/utau; rb = abs(dU[0])
    lo = yh <= 1.0
    yp_b = yp[lo]*np.sqrt(rb); eta_b = yh[lo]; Re_b = Re_avg*np.sqrt(rb)
    tau_b = np.clip(tau_avg[lo]/rb, 0, None); Vb = np.full(int(lo.sum()), v0p/np.sqrt(rb))
    pred = predict_pe(yp_b, eta_b, Re_b, tau_b, Vb, 0.0)
    pred0 = predict_pe(yp_b, eta_b, Re_b, tau_b, np.zeros_like(yp_b), 0.0)
    record(nm + ' (blowing side)', 'H NEW PHYSICS transpiration', Re_b, yp_b, eta_b, pe[lo], pred,
           pred_v0=pred0, note='local blowing-wall scaling; tau overshoots 1; eps=enstrophy (FDY def.)',
           panel=(2, 2) if '480' in fn else None)

    # Suction side, scored with the same outer length h for transparency.  Its
    # zero-total-stress point lies much closer than h to the suction wall, so
    # this is deliberately an ill-posed/failure-mode application of the map.
    rs = abs(dU[-1])
    idx = np.where(yh >= 1.0)[0][::-1]
    yp_s = (yp[-1] - yp[idx])*np.sqrt(rs); eta_s = 2.0 - yh[idx]
    Re_s = Re_avg*np.sqrt(rs)
    tau_s = np.clip(-tau_avg[idx]/rs, 0, None)
    Vs = np.full(len(idx), -v0p/np.sqrt(rs))
    pred_s = predict_pe(yp_s, eta_s, Re_s, tau_s, Vs, 0.0)
    pred_s0 = predict_pe(yp_s, eta_s, Re_s, tau_s, np.zeros_like(yp_s), 0.0)
    record(nm + ' (suction side, h-map)', 'H NEW PHYSICS transpiration', Re_s, yp_s, eta_s, pe[idx], pred_s,
           pred_v0=pred_s0, note='local suction-wall scaling; zero-stress point is far inside eta=1; eps=enstrophy (FDY def.)')

# ---------------------------------------------------------------- I WingData LES (appendix)
import scipy.io as sio
d = sio.loadmat(f'{ID}/wingdata/naca4412.mat', squeeze_me=False, struct_as_record=False)
arr = d['top10n'][0]
for i in [10, 25, 33, 39]:
    st = arr[i]
    yn = st.yn.ravel().astype(float); U = st.U.ravel(); V = st.V.ravel(); uv = st.uv.ravel()
    Pk = st.Pk.ravel(); Dk = st.Dk.ravel()
    ut = float(st.ut); nuw = float(st.nu); d99 = float(st.delta99); Re = float(st.Ret); beta = float(st.beta)
    yp = yn*ut/nuw; eta = yn/d99
    tau = (nuw*np.gradient(U, yn) - uv)/ut**2
    pe = Pk/np.where(-Dk > 0, -Dk, np.nan)
    pred = predict_pe(yp, eta, Re, np.clip(tau, 0, None), V/ut, 0.0)
    pred0 = predict_pe(yp, eta, Re, np.clip(tau, 0, None), np.zeros_like(yp), 0.0)
    record(f'NACA4412 LES st{i} beta={beta:.1f}', 'I APPENDIX wing LES (caveated)', Re, yp, eta, pe, pred,
           pred_v0=pred0, note='well-resolved LES; rotated frame; budget conventions differ from DNS')

# ---------------------------------------------------------------- outputs
import csv
with open('/home/user/independent_results.csv', 'w', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=['name', 'group', 'Retau', 'n', 'R2', 'peak_DNS', 'peak_pred', 'R2_diag_V0', 'note'])
    w.writeheader(); w.writerows(RES)

fig, axes = plt.subplots(3, 3, figsize=(11, 9))
for (r, c), (name, eta, pe, pred) in sorted(PANELS.items()):
    ax = axes[r][c]
    m = eta <= 1.0001
    ax.plot(eta[m], pe[m], 'o', ms=2.5, alpha=0.55, label='DNS')
    ax.plot(eta[m], pred[m], '-', lw=1.4, label='frozen U4')
    ax.set_xlim(0, 1); ax.set_ylim(-0.4, 3.0)
    ax.set_title(name, fontsize=9); ax.grid(alpha=0.3)
    if r == 2: ax.set_xlabel(r'$\eta$')
    if c == 0: ax.set_ylabel(r'$P/\varepsilon$')
axes[0][0].legend(fontsize=8)
fig.suptitle('Frozen universal P/eps formula on independent flows (no refitting)', fontsize=12)
fig.tight_layout(rect=[0, 0, 1, 0.97])
fig.savefig('/home/user/independent_profiles.pdf')
fig.savefig('/home/user/independent_profiles.png', dpi=150)
print('wrote independent_results.csv, independent_profiles.pdf/png')
