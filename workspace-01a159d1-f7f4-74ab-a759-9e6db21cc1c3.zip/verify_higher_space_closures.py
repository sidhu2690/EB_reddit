import os, re
import numpy as np
from scipy.optimize import least_squares

DNS_DIR = "/home/user/dns_data"

def numeric_rows(path, min_cols):
    rows = []
    with open(path, "r", errors="replace") as f:
        for line in f:
            s = line.strip()
            if not s or s.startswith(("%", "#")): continue
            parts = s.split()
            if len(parts) < min_cols: continue
            try: rows.append([float(x) for x in parts])
            except ValueError: continue
    return np.asarray(rows, dtype=float)

def load_lm_channel(re_tau: int):
    raw = np.loadtxt(os.path.join(DNS_DIR, f"LM_Channel_{re_tau:04d}_RSTE_k_prof.dat"), comments="%")
    yd, yp, prod, eps = raw[:, 0], raw[:, 1], raw[:, 2], np.abs(raw[:, 7])
    return {"id": f"LM_{re_tau}", "re_tau": float(re_tau), "yd": yd, "yp": yp, "prod": prod, "eps": eps, "pe": prod / np.maximum(eps, 1e-30)}

def load_lm_couette(re_tau: int):
    raw = np.loadtxt(os.path.join(DNS_DIR, f"LM_Couette_R{re_tau:04d}_020PI_RSTE_k_prof.dat"), comments="%")
    yd, yp, prod, eps = raw[:, 0], raw[:, 1], raw[:, 2], np.abs(raw[:, 7])
    return {"id": f"Couette_{re_tau}", "re_tau": float(re_tau), "yd": yd, "yp": yp, "prod": prod, "eps": eps, "pe": prod / np.maximum(eps, 1e-30)}

def load_upm_channel(re_tau: int):
    raw = numeric_rows(os.path.join(DNS_DIR, "upm_channel", f"UPM_Re{re_tau}_balance_kbal.dat"), 4)
    yd, yp, eps, prod = raw[:, 0], raw[:, 1], np.abs(raw[:, 2]), raw[:, 3]
    return {"id": f"UPM_{re_tau}", "re_tau": float(re_tau), "yd": yd, "yp": yp, "prod": prod, "eps": eps, "pe": prod / np.maximum(eps, 1e-30)}

def load_kth_tbl(re_theta: int):
    path = os.path.join(DNS_DIR, "kth_tbl", f"bud_{re_theta:04d}_dns_k.prof")
    re_tau = None
    with open(path, "r", errors="replace") as f:
        for line in f:
            m = re.search(r"Re_\{\\tau\}\s*=\s*([0-9.]+)", line)
            if m: re_tau = float(m.group(1)); break
    raw = numeric_rows(path, 9)
    yd, yp, prod, eps = raw[:, 0], raw[:, 1], raw[:, 3] * re_tau, np.abs(raw[:, 4]) * re_tau
    return {"id": f"KTH_{re_theta}", "re_tau": re_tau, "yd": yd, "yp": yp, "prod": prod, "eps": eps, "pe": prod / np.maximum(eps, 1e-30)}

def load_elkhoury_pipe(re_tau: int):
    comps = [numeric_rows(os.path.join(DNS_DIR, "el_khoury_pipe", f"{re_tau}_{c}_Budget.dat"), 8) for c in ("RR", "TT", "ZZ")]
    n = min(c.shape[0] for c in comps)
    comps = [c[:n] for c in comps]
    yd, yp = comps[0][:, 0], comps[0][:, 1]
    prod = 0.5 * sum(c[:, 2] for c in comps)
    eps = -0.5 * sum(c[:, 7] for c in comps)
    return {"id": f"Pipe_{re_tau}", "re_tau": float(re_tau), "yd": yd, "yp": yp, "prod": prod, "eps": eps, "pe": prod / np.maximum(eps, 1e-30)}

def get_inner_slice(d):
    yp, yd, prod, eps, pe = d["yp"], d["yd"], d["prod"], d["eps"], d["pe"]
    m = (yp > 1.0) & (yp <= min(150.0, 0.30 * d["re_tau"])) & (eps > 1e-6) & (pe > 0.01) & np.isfinite(pe)
    return yp[m], yd[m], prod[m], eps[m], pe[m]

def get_full_slice(d):
    yp, yd, prod, eps, pe = d["yp"], d["yd"], d["prod"], d["eps"], d["pe"]
    m = (yp >= 0.1) & (yd <= 1.0) & (eps > 1e-8) & np.isfinite(pe) & (pe > 0.0)
    return yp[m], yd[m], prod[m], eps[m], pe[m]

def get_sub_slice(d):
    yp, yd, prod, eps, pe = d["yp"], d["yd"], d["prod"], d["eps"], d["pe"]
    m = (yp >= 0.1) & (yp <= 5.0) & (eps > 1e-6) & (pe > 0.0) & np.isfinite(pe)
    return yp[m], yd[m], prod[m], eps[m], pe[m]

ch_tr = [load_lm_channel(1000), load_lm_channel(5200)]
ch_ho = [load_lm_channel(180), load_lm_channel(550), load_lm_channel(2000)]
upm_all = [load_upm_channel(r) for r in [180, 550, 950, 2000]]
kth_all = [load_kth_tbl(r) for r in [670, 1000, 1410, 2000, 2540, 3030, 3270, 3630, 3970, 4060]]
pipe_all = [load_elkhoury_pipe(r) for r in [180, 360, 550, 1000]]
cou_all = [load_lm_couette(r) for r in [93, 220, 500]]

def r2_score(y, yhat):
    return 1.0 - np.sum((y - yhat)**2) / np.sum((y - y.mean())**2)

# =========================================================================
# 1D CLOSURES (FROZEN PARAMETERS TRAINED STRICTLY ON LM Re_tau IN {1000, 5200})
# =========================================================================
def ox_pysr(yp, yd=None):
    return np.tanh(0.128 * yp) / (np.tanh(0.053 * yp - 0.620) + 5.78 / yp)

def ox_m16(yp, yd=None):
    return (np.tanh(0.111 * yp)**2) / (np.tanh(0.052 * yp - 0.443) + 2.888 / yp)

def semban_1d_prev(yp, yd=None):
    a1, a2, c0, c1, b1, c2, b2 = 0.15285969, 0.00727943, 1.17160514, 0.05100360, 0.19058360, 0.01273794, 0.01690060
    return (np.tanh(a1*yp + a2*yp**2)**3) * (c0 + c1*(yp**2)*np.exp(-b1*yp) - c2*yp*np.exp(-b2*yp))

def semban_1d_6p_hypbeta(yp, yd=None):
    a1, a2, c0, c1, b1, b2 = 0.15975450, 0.00643550, 1.04566419, 0.05713871, 0.19687982, 0.01317963
    th = np.tanh(b2 * yp)
    return (np.tanh(a1*yp + a2*yp**2)**3) * (c0 * (1.0 - (th**2)*(1.0 - th)) + c1*(yp**2)*np.exp(-b1*yp))

def semban_1d_7p_gausshyp(yp, yd=None):
    a1, a2, c0, c1, b1, b12, b2 = 0.16078482, 0.00541424, 1.03372444, 0.07204498, 0.22254531, -0.00077833, 0.01415203
    th = np.tanh(b2 * yp)
    return (np.tanh(a1*yp + a2*yp**2)**3) * (c0 * (1.0 - (th**2)*(1.0 - th)) + c1*(yp**2)*np.exp(-b1*yp - b12*yp**2))

def semban_1d_7p_algpade(yp, yd=None):
    a1, a2, c0, c1, b1, c2, b2 = 0.15388683, 0.00642758, 1.17298963, 0.05561960, 0.20719638, 0.00024162, 0.02117166
    return (np.tanh(a1*yp + a2*yp**2)**3) * (c0 + c1*(yp**2)*np.exp(-b1*yp) - c2*(yp**2) / (1.0 + (b2*yp)**3))

print("========================================================================================================================")
print("1D INNER-LAYER CLOSURE BENCHMARK ACROSS ALL 26 DNS PROFILES (TRAINED STRICTLY ON LM Re_tau IN {1000, 5200})")
print("========================================================================================================================")
print(f"{'Model Name':30s} | {'k':2s} | {'Train(2)':8s} | {'HO_LM(3)':8s} | {'UPM(4)':8s} | {'KTH(10)':8s} | {'Pipe(4)':8s} | {'Cou(3)':8s} | {'Mean24':8s} | {'Sub_HO':7s} | {'Diss_HO':7s}")
print("-" * 120)
for name, k, fn in [
    ("Oxford_PySR (2026)", 4, ox_pysr),
    ("Oxford_M16 (2026)", 4, ox_m16),
    ("SEMBAN-1D (Prev 7p)", 7, semban_1d_prev),
    ("SEMBAN-1D-6p (HypBeta) [NEW]", 6, semban_1d_6p_hypbeta),
    ("SEMBAN-1D-7p (GaussHyp) [NEW]", 7, semban_1d_7p_gausshyp),
    ("SEMBAN-1D-7p (AlgPade) [NEW]", 7, semban_1d_7p_algpade),
]:
    tr = np.mean([r2_score(get_inner_slice(d)[4], fn(get_inner_slice(d)[0])) for d in ch_tr])
    ho = np.mean([r2_score(get_inner_slice(d)[4], fn(get_inner_slice(d)[0])) for d in ch_ho])
    upm = np.mean([r2_score(get_inner_slice(d)[4], fn(get_inner_slice(d)[0])) for d in upm_all])
    kth = np.mean([r2_score(get_inner_slice(d)[4], fn(get_inner_slice(d)[0])) for d in kth_all])
    pip = np.mean([r2_score(get_inner_slice(d)[4], fn(get_inner_slice(d)[0])) for d in pipe_all])
    cou = np.mean([r2_score(get_inner_slice(d)[4], fn(get_inner_slice(d)[0])) for d in cou_all])
    m24 = np.mean([r2_score(get_inner_slice(d)[4], fn(get_inner_slice(d)[0])) for d in (ch_ho + upm_all + kth_all + pipe_all + cou_all)])
    se_ho = np.mean([100.0 * np.mean(np.abs(fn(get_sub_slice(d)[0]) - get_sub_slice(d)[4]) / get_sub_slice(d)[4]) for d in ch_ho])
    dr_ho = np.mean([100.0 * (1.0 - np.sqrt(np.mean((get_inner_slice(d)[2]/np.maximum(fn(get_inner_slice(d)[0]), 1e-6) - get_inner_slice(d)[3])**2)) / np.sqrt(np.mean((get_inner_slice(d)[2] - get_inner_slice(d)[3])**2))) for d in ch_ho])
    print(f"{name:30s} | {k:2d} | {tr:8.5f} | {ho:8.5f} | {upm:8.5f} | {kth:8.5f} | {pip:8.5f} | {cou:8.5f} | {m24:8.5f} | {se_ho:6.2f}% | {dr_ho:6.2f}%")

# =========================================================================
# 2D FULL-DOMAIN CLOSURES (FROZEN PARAMETERS TRAINED STRICTLY ON LM {1000, 5200})
# =========================================================================
def semban_2d_prev(yp, yd):
    a1, a2, c0, c1, d1, b1, c2, b2, g1, g2 = 0.15707888, 0.00768198, 1.06376548, 0.05294048, -0.00178468, 0.18414932, 0.01027500, 0.02182203, 3.95416384, -1.31213415
    z = np.maximum(1.0 - yd, 0.0)
    lr = np.log(np.maximum(yp, 1e-12) / (1000.0 * np.maximum(yd, 1e-12)))
    return (np.tanh(a1*yp + a2*yp**2)**3) * (c0 + (c1 + d1*lr)*(yp**2)*np.exp(-b1*yp) - c2*yp*np.exp(-b2*yp)) * ((np.tanh(g1*z + g2*z**2)**2)/(np.tanh(g1+g2)**2))

def semban_2d_9p_new(yp, yd):
    a1, a2, c0, c1, d1, b1, b2, g0, g1 = 0.15918458, 0.00637798, 1.05422868, 0.05971709, -0.00279611, 0.19869617, 0.01314467, 0.07794801, 3.93248449
    z = np.maximum(1.0 - yd, 0.0)
    th = np.tanh(b2 * yp)
    re_ratio = np.maximum(yp, 1e-12) / (500.0 * np.maximum(yd, 1e-12))
    lr = np.log(1.0 + re_ratio) - np.log(3.0)
    gate = np.tanh(a1*yp + a2*yp**2)**3
    inner = c0 * (1.0 - (th**2)*(1.0 - th)) + (c1 + d1*lr)*(yp**2)*np.exp(-b1*yp)
    wake = (1.0 - g0 * yd) * ((np.tanh(g1*z)**2) / (np.tanh(g1)**2))
    return gate * inner * wake

def semban_2d_10p_new(yp, yd):
    a1, a2, c0, c1, d1, b1, c2, b2, g0, g1 = 0.15849553, 0.00643477, 1.06760024, 0.05904547, -0.00285867, 0.19887666, 1.17471476, 0.01305493, 0.11784810, 4.01117854
    z = np.maximum(1.0 - yd, 0.0)
    th = np.tanh(b2 * yp)
    re_ratio = np.maximum(yp, 1e-12) / (500.0 * np.maximum(yd, 1e-12))
    lr = np.log(1.0 + re_ratio) - np.log(3.0)
    gate = np.tanh(a1*yp + a2*yp**2)**3
    inner = c0 - c2*(th**2)*(1.0 - th) + (c1 + d1*lr)*(yp**2)*np.exp(-b1*yp)
    wake = (1.0 - g0 * yd) * ((np.tanh(g1*z)**2) / (np.tanh(g1)**2))
    return gate * inner * wake

print("\n=========================================================================================================================================")
print("2D INNER + OUTER CLOSURE BENCHMARK ACROSS ALL 23 BOUNDARY-LAYER/CHANNEL/PIPE PROFILES (TRAINED STRICTLY ON LM Re_tau IN {1000, 5200})")
print("=========================================================================================================================================")
print(f"{'Model Name':30s} | {'k':2s} | {'TrIn':7s} {'TrFl':7s} | {'HO_In':7s} {'HO_Fl':7s} | {'UPM_In':7s} {'UPM_Fl':7s} | {'KTH_In':7s} | {'Pip_In':7s} {'Pip_Fl':7s} | {'Mean21':7s} | {'Sub_HO':6s} | {'Diss_HO':7s}")
print("-" * 137)
for name, k, fn in [
    ("SEMBAN-2D (Prev 10p)", 10, semban_2d_prev),
    ("SEMBAN-2D-9p (HypBeta) [NEW]", 9, semban_2d_9p_new),
    ("SEMBAN-2D-10p (FreeBeta) [NEW]", 10, semban_2d_10p_new),
]:
    tr_in = np.mean([r2_score(get_inner_slice(d)[4], fn(get_inner_slice(d)[0], get_inner_slice(d)[1])) for d in ch_tr])
    tr_fl = np.mean([r2_score(get_full_slice(d)[4], fn(get_full_slice(d)[0], get_full_slice(d)[1])) for d in ch_tr])
    ho_in = np.mean([r2_score(get_inner_slice(d)[4], fn(get_inner_slice(d)[0], get_inner_slice(d)[1])) for d in ch_ho])
    ho_fl = np.mean([r2_score(get_full_slice(d)[4], fn(get_full_slice(d)[0], get_full_slice(d)[1])) for d in ch_ho])
    upm_in = np.mean([r2_score(get_inner_slice(d)[4], fn(get_inner_slice(d)[0], get_inner_slice(d)[1])) for d in upm_all])
    upm_fl = np.mean([r2_score(get_full_slice(d)[4], fn(get_full_slice(d)[0], get_full_slice(d)[1])) for d in upm_all])
    kth_in = np.mean([r2_score(get_inner_slice(d)[4], fn(get_inner_slice(d)[0], get_inner_slice(d)[1])) for d in kth_all])
    pip_in = np.mean([r2_score(get_inner_slice(d)[4], fn(get_inner_slice(d)[0], get_inner_slice(d)[1])) for d in pipe_all])
    pip_fl = np.mean([r2_score(get_full_slice(d)[4], fn(get_full_slice(d)[0], get_full_slice(d)[1])) for d in pipe_all])
    all21 = [r2_score(get_inner_slice(d)[4], fn(get_inner_slice(d)[0], get_inner_slice(d)[1])) for d in (ch_ho + upm_all + kth_all + pipe_all)]
    se_ho = np.mean([100.0 * np.mean(np.abs(fn(get_sub_slice(d)[0], get_sub_slice(d)[1]) - get_sub_slice(d)[4]) / get_sub_slice(d)[4]) for d in ch_ho])
    dr_ho = np.mean([100.0 * (1.0 - np.sqrt(np.mean((get_inner_slice(d)[2]/np.maximum(fn(get_inner_slice(d)[0], get_inner_slice(d)[1]), 1e-6) - get_inner_slice(d)[3])**2)) / np.sqrt(np.mean((get_inner_slice(d)[2] - get_inner_slice(d)[3])**2))) for d in ch_ho])
    print(f"{name:30s} | {k:2d} | {tr_in:7.5f} {tr_fl:7.5f} | {ho_in:7.5f} {ho_fl:7.5f} | {upm_in:7.5f} {upm_fl:7.5f} | {kth_in:7.5f} | {pip_in:7.5f} {pip_fl:7.5f} | {np.mean(all21):7.5f} | {se_ho:5.2f}% | {dr_ho:6.2f}%")
