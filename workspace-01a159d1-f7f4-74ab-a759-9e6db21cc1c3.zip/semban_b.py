#!/usr/bin/env python3
"""
SEMBAN-B v2: budget-physics general closure for P/eps across all 5 wall-bounded families.
  P/eps = F_in(y+) * W_fam(eta) + CREST_fam(y+, eta)
Mechanisms (all measured from the 26 DNS TKE budgets):
  F_in   : universal inner law (viscous gate x [1 - transport wave + buffer peak])
  W_fam  : outer wake from the total-stress law  tau_tot = 1 - alpha_p*eta
           channel/pipe: (1-g0*eta) tanh^2(g1(1-eta));  TBL: logistic edge at eta_e;
           Couette: core droop (no wake zero; tau_tot = 1).
  CREST  : log-layer energy-export bump: channel inner (y+ ~ O(200-350), amplitude
           grows ~ ln Re via measured export law); TBL outer growth-convection
           plateau (eta ~ 0.58); pipe/couette weak.
Protocol: channel constants frozen from LM{1000,5200}; family constants identified
once (TBL: KTH_4060; Pipe: Pipe_550; Couette: Cou_220+Cou_500) and validated on rest.
"""
import numpy as np
from scipy.optimize import least_squares
from budget_loader import load_all_budgets

# ---------------- frozen inner core (fitted earlier on LM {1000, 5200})
A1, A2, C1, B1, B2 = 0.16234303, 0.00596653, 0.06272513, 0.20161904, 0.02065071

def F_in(yp, c1):
    G = np.tanh(A1*yp + A2*yp**2)**3
    T = np.tanh(B2*yp)
    return G*(1.0 - T**5*(1.0 - T**2) + c1*yp**2*np.exp(-B1*yp))

def peak_of_c1(c1):
    ypg = np.linspace(8.0, 16.0, 400)
    return F_in(ypg, c1).max()

def c1_for_peak(pk):
    lo, hi = 0.005, 0.5
    for _ in range(60):
        mid = 0.5*(lo+hi)
        if peak_of_c1(mid) < pk: lo = mid
        else: hi = mid
    return 0.5*(lo+hi)

# ---------------- channel laws, frozen on LM {1000, 5200}
def eps_w_ch(Re): return 0.4886 - 1.641/np.log(Re)          # wall dissipation law
def peak_ch(Re):  return 2.066 - 1.135*eps_w_ch(Re)         # buffer-peak law
def Ec_ch(Re):    return max(0.0, 0.0369*np.log(Re) - 0.220)  # crest export law
def yc_ch(Re):    return 61.8*np.log(Re) - 202.0            # crest location law
G0_CH, G1_CH = 0.07759239, 3.92368480

def W_ch(eta): return (1.0 - G0_CH*eta)*np.tanh(G1_CH*(1.0-eta))**2

def crest_ch(yp, Re):
    Ec, yc = Ec_ch(Re), yc_ch(Re)
    if Ec <= 0.0: return np.zeros_like(yp)
    return Ec*np.exp(-0.5*((np.log(np.maximum(yp,1e-6)) - np.log(yc))/0.55)**2)

# ---------------- family models
def predict(yp, eta, Re, fam, P):
    pk = P["peak"](Re) if callable(P["peak"]) else P["peak"]
    Fin = F_in(yp, c1_for_peak(pk))
    if fam == "ch":
        return Fin*W_ch(eta) + crest_ch(yp, Re)
    if fam == "tbl":
        W = 1.0/(1.0+np.exp((eta-P["e0"])/P["we"]))
        W *= (1.0+np.exp(-P["e0"]/P["we"]))          # W(0)=1
        cr = P["Et"]*np.exp(-0.5*((eta-P["etc"])/P["wt"])**2)
        return Fin*W + cr
    if fam == "pipe":
        W = (1.0 - P["g0p"]*eta)*np.tanh(P["g1p"]*(1.0-eta))**2
        cr = P["Ep"]*np.exp(-0.5*((np.log(np.maximum(yp,1e-6))-np.log(P["ycp"]))/0.55)**2)
        return Fin*W + cr
    if fam == "cou":
        W = 1.0 - P["kcore"]*np.tanh(eta/P["etc2"])**2
        cr = P["Ec"]*np.exp(-0.5*((np.log(np.maximum(yp,1e-6))-np.log(P["ycc"]))/0.55)**2)
        return Fin*W + cr
    raise ValueError(fam)

def r2_of(pred, pe): return 1.0 - np.sum((pred-pe)**2)/np.sum((pe-pe.mean())**2)

def fit_on(profs, fam, P, keys):
    def resid(x):
        Q = dict(P); Q.update(dict(zip(keys, x)))
        out = []
        for p in profs:
            pe = p["P"]/p["eps"]
            out.append(predict(p["yp"], p["eta"], p["re_tau"], fam, Q) - pe)
        return np.concatenate(out)
    x0 = [P[k] for k in keys]
    r = least_squares(resid, x0, method="trf", max_nfev=20000, ftol=1e-14, xtol=1e-14)
    Q = dict(P); Q.update(dict(zip(keys, r.x)))
    return Q

if __name__ == "__main__":
    profs = load_all_budgets()
    by = {p["id"]: p for p in profs}
    fam_of = {"LM":"ch", "UPM":"ch", "KTH":"tbl", "Pipe":"pipe", "Cou":"cou"}

    P = {}
    P["ch"] = dict(peak=peak_ch)
    # TBL: identify on KTH_4060 only
    P["tbl"] = fit_on([by["KTH_4060"]], "tbl",
                      dict(peak=1.758, e0=0.93, we=0.035, Et=0.17, etc=0.58, wt=0.28),
                      ["e0","we","Et","etc","wt"])
    print("TBL identified on KTH_4060:", {k: (round(v,4) if isinstance(v,float) else v) for k,v in P["tbl"].items()})
    # Pipe: identify on Pipe_550
    P["pipe"] = fit_on([by["Pipe_550"]], "pipe",
                       dict(peak=1.785, g0p=0.10, g1p=4.2, Ep=0.05, ycp=230.0),
                       ["g0p","g1p","Ep","ycp"])
    print("Pipe identified on Pipe_550:", {k: round(v,4) for k,v in P["pipe"].items()})
    # Couette: identify on Cou_220 + Cou_500
    P["cou"] = fit_on([by["Cou_220"], by["Cou_500"]], "cou",
                      dict(peak=1.745, kcore=0.15, etc2=0.35, Ec=0.10, ycc=190.0),
                      ["kcore","etc2","Ec","ycc"])
    print("Couette identified on Cou_220+Cou_500:", {k: round(v,4) for k,v in P["cou"].items()})

    print()
    print("="*104)
    print("SEMBAN-B FROZEN EVALUATION ON ALL 26 DNS BUDGET PROFILES")
    print("="*104)
    print(f"{'id':10s} {'Re':>6s} {'fam':4s} {'R2':>8s} {'pk_err':>7s} {'tr_err':>7s} {'cr_err':>7s} {'outer_err':>9s}")
    r2s = []
    for p in profs:
        fam = fam_of[p["family"]]
        Q = P[fam]
        pred = predict(p["yp"], p["eta"], p["re_tau"], fam, Q)
        pe = p["P"]/p["eps"]
        r2 = r2_of(pred, pe); r2s.append(r2)
        m = p["yp"] < 30
        pk_e = pred[m].max() - pe[m].max()
        m2 = (p["yp"] >= 30) & (p["yp"] <= 120)
        tr_e = pred[m2].min() - pe[m2].min() if m2.sum() > 2 else np.nan
        m3 = (p["yp"] >= 130) & (p["eta"] <= 0.75)
        cr_e = (pred[m3].max() - pe[m3].max()) if m3.sum() > 2 else np.nan
        m4 = p["eta"] >= 0.5
        w_e = np.median(np.abs(pred[m4]-pe[m4])) if m4.sum() > 2 else np.nan
        print(f"{p['id']:10s} {p['re_tau']:6.0f} {fam:4s} {r2:8.5f} {pk_e:+7.3f} {tr_e:+7.3f} {cr_e:+7.3f} {w_e:9.3f}")
    print(f"\nMean R2 over 26 profiles: {np.mean(r2s):.5f} | median {np.median(r2s):.5f} | min {np.min(r2s):.5f}")
