# One universal formula for $P/\varepsilon$ across channels, pipes, boundary layers, and Couette flow

**Question.** Can a *single* physics-based, dimensionally consistent formula predict
$P/\varepsilon$ in plane channels, pipes, zero-pressure-gradient (ZPG) turbulent
boundary layers, and plane Couette flow — with one frozen parameter set, no
family-specific branches, and no per-profile refitting?

**Answer. Yes.** The formula below uses only physical descriptors
$(y^+,\ \eta,\ Re_\tau,\ \tau_{tot}(\eta),\ V^+(\eta),\ m)$ and 14 shared fitted
constants. On the 26 DNS profiles (turbulent domain $\eta\le1.05$) it gives
mean $R^2=0.99540$, minimum $0.98095$ — slightly *better* than the previous
family-specific SEMBAN-B on the same domain ($0.99275$, min $0.95152$).
In leave-one-flow-family-out (LOFO) validation, where every fitted constant is
re-estimated without the held-out family, the held-out means are
Channel $0.99611$, Pipe $0.99653$, TBL $0.98874$, Couette $0.98726$.

---

## 1. The formula

**Inputs.** $y^+$ (inner coordinate), $\eta=y/\delta$ (outer coordinate;
$\delta$ = channel half-height, pipe radius, or $\delta_{99}$),
$Re_\tau$, the total-stress profile
$\tau(\eta)=\big(dU^+/dy^+-\langle u'v'\rangle^+\big)$,
the mean wall-normal velocity $V^+(\eta)$, and the geometry exponent
$m=0$ (planar) or $1$ (axisymmetric pipe).

For parallel flows $\tau$ and $V^+$ are not extra data: mean momentum gives
$\tau=1-\alpha\eta$ with $\alpha=1$ (pressure-driven channel/pipe) or
$\alpha=0$ (Couette), and continuity gives $V^+\equiv0$. Only in a developing
layer must $\tau(\eta)$ and $V^+(\eta)$ come from the mean flow (here, the KTH
mean profiles). Measured $\tau$ for channels/pipes agrees with $1-\eta$ to
$\le 0.018$, confirming the loader.

**Peak (equal-stress bound + dissipation scaling).** With
$\tau_p=\tau(y^+=12)$,
$$\varepsilon_{pk}=E_0\,\tau_p^{r_p},\qquad
p_{peak}=\frac{\tau_p^{2}}{4\varepsilon_{pk}} .$$
In all 26 profiles the measured production at the $P/\varepsilon$ peak satisfies
$4P_{pk}/\tau_p^2=0.99$–$1.00$: the peak sits where viscous and Reynolds stresses
are equal, so $P_{pk}=\tau_p^2/4$ is a kinematic bound, not a fit. All peak
variation across families and Reynolds numbers is then carried by
$\varepsilon_{pk}\propto\tau_p^{2.43}$ (peak-height RMSE $0.022$, max $0.053$).

**Inner core + log crest.**
$$B=F_{in}(y^+;p_{peak})+E_c(Re_\tau)\,
\exp\!\Big[-\tfrac12\big(\ln(y^+/y_c)/w\big)^2\Big],\qquad
y_c=\sqrt{100\,Re_\tau},\quad
E_c=E_\infty\big(1-\sqrt{150/Re_\tau}\big)_+ ,$$
$$F_{in}=\tanh^3\!\big(a_1y^++a_2y^{+2}\big)
\Big[1-T^5(1-T^2)+c_1y^{+2}e^{-b_e y^+}\Big],\quad T=\tanh(b_wy^+),$$
with $c_1$ set so $\max F_{in}=p_{peak}$. The crest sits at the mesolayer
geometric mean of the inner scale $y^+\sim100$ and the outer scale $Re_\tau$,
and its amplitude switches on only once a log layer exists
($Re_\tau\gtrsim150$) and saturates — this boundedness is what makes
Reynolds-number extrapolation safe (an unbounded $\ln Re$ crest law trained
without channels fails catastrophically at $Re_\tau=5200$, $R^2=0.88$).

**Outer factors and growth source.**
$$\frac{P}{\varepsilon}
= B\;\underbrace{\frac{\tanh^2(a\tau)}{\tanh^2(a)}}_{\text{stress wake}}\;
\underbrace{\Big[1-c_c\tanh^2\!\big(y^+/300\big)\,\eta^2\tau^2\Big]}_{\text{core import}}\;
\underbrace{\frac{1}{1+m\eta/4}}_{\text{axisymmetry}}
\;+\;\underbrace{G_0\,V^+\Big(\frac{\ln Re_\tau}{\ln1000}\Big)^{r_g}
\eta^{p_g}\tanh^2\!\big(a\tau^{q_g}\big)}_{\text{growth / entrainment}} .$$

**Frozen constants** (one all-data fit; LOFO refits differ by $\lesssim3\%$ except $r_p$, $w$):

| $a_1$ | $a_2$ | $b_e$ | $b_w$ | $E_0$ | $r_p$ | $E_\infty$ | $w$ | $a$ | $c_c$ | $G_0$ | $r_g$ | $p_g$ | $q_g$ |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 0.160773 | 0.00540632 | 0.210307 | 0.0195789 | 0.140725 | 2.42579 | 0.119023 | 0.456099 | 3.92809 | 0.534588 | 14.7805 | 1.8693 | 0.974179 | 0.566203 |

Fixed structural numbers: peak location $y^+=12$, crest onset $Re_\tau=150$,
crest centre $\sqrt{100Re_\tau}$, core switch $y^+=300$, core powers
$\eta^2\tau^2$, geometry denominator $1+m\eta/4$ (**prescribed, not fitted**).

---

## 2. What the old SEMBAN-B wake constants actually were

| SEMBAN-B (family-specific) | Universal replacement | Physical meaning |
|---|---|---|
| Channel/pipe $\tanh^2[g_1(1-\eta)]$, $g_1=3.92$–$4.16$ | $\tanh^2(a\tau)/\tanh^2(a)$, $a=3.928$ | The wake is controlled by **total stress**, not geometric distance. For channel/pipe $\tau=1-\eta$, so the old form was the same law in disguise. Couette has $\tau\equiv1$ → no wake zero, with no separate branch. Near a symmetry centre $P/\varepsilon\to (a^2/\tanh^2a)\,\tau^2\approx15.4(1-\eta)^2$ (DNS centre coefficient $13$–$16$): production $\tau_RS$ vanishes quadratically while $\varepsilon$ tends to a transported floor. |
| Linear prefactors $(1-g_0\eta)$: $g_0=0.078$ channel, $0.297$ pipe | $1/(1+m\eta/4)$ × core factor | Most of the channel–pipe difference is **axisymmetric collection**: the prescribed factor gives pipe/channel $=0.889$ at $\eta=0.5$ and $0.80$ at the axis, matching the DNS centre-coefficient ratio $\approx12.2/15.4=0.79$. The small planar residue is the $\eta^2\tau^2$ core term. |
| TBL logistic edge ($e_0=0.981$, $w_e=0.0655$) + plateau $E_t=0.186$ at $\eta\approx0.6$ | Stress wake with measured $\tau(\eta)$ + growth term $\propto V^+$ | The TBL "edge" is where the *stress* (still $\tau\approx0.07$ at $\delta_{99}$) finally vanishes near $1.1\delta_{99}$, and the plateau is the **streamwise-development (convection/entrainment) source**, localised by $V^+(\eta)\,\eta^{p_g}\tanh^2(a\tau^{q_g})$. Its fitted strength is $G_0(\ln Re/\ln1000)^{r_g}\approx15$ at $Re_\tau=1000$; even the a-priori value $2/\kappa^2=11.9$ ($\kappa=0.41$) with $r_g=2$, $p_g=q_g=\tfrac12$ predicts a fully held-out TBL family at $R^2=0.98874$. |
| Couette core $1-k_{core}\tanh^2(\eta/\eta_{c2})$ | $1-c_c\tanh^2(y^+/300)\eta^2\tau^2$, $c_c=0.535$ | A **constant-stress core-import fraction** $c_c\approx\tfrac12$: beyond the log layer ($y^+\gtrsim300$), in any region where $\tau$ remains $O(1)$, about half the dissipation is imported by transport rather than produced locally. It is invisible in channels/pipes because $\tau^2$ kills it where the stress falls. Frozen at the prior $c_c=\tfrac12$ (not fitted), it predicts held-out Couette flow at $R^2=0.98726$. |
| Family crest constants | $y_c=\sqrt{100Re_\tau}$, $E_c=E_\infty(1-\sqrt{150/Re_\tau})_+$ | One mesolayer crest for all flows; amplitude set by log-layer extent only. |

---

## 3. Validation

Primary domain $\eta\le1.05$ (beyond $\sim1.1\delta_{99}$ both $P$ and
$\varepsilon$ vanish in a TBL and their ratio is ill-conditioned; full-raw
scores are also given). Objective for every fit: profile-balanced residuals
on this domain. Budget closure of the underlying data: max residual
$1.6\times10^{-3}$ over all 26 profiles.

**Frozen all-data fit** (`universal_pe_model.py`):

| domain | mean | median | min |
|---|---|---|---|
| $\eta\le1.05$ | 0.99540 | 0.99681 | 0.98095 (Cou_500) |
| full raw | 0.99706 | 0.99881 | 0.98095 |

Family means ($\eta\le1.05$): Channel (LM+UPM) $0.99748$, Pipe $0.99725$,
TBL $0.99492$, Couette $0.98832$. SEMBAN-B (family-specific) on the same
domain: mean $0.99275$, min $0.95152$.

**Leave-one-flow-family-out** (`universal_lofo4.py`). All 14 constants are
refit on the training families only (including the inner-core constants).
Two theory priors are frozen *only* where the held-out family is the sole
carrier of that mechanism in the data: the growth coefficients
($G_0=2/\kappa^2$, $r_g=2$, $p_g=q_g=\tfrac12$) when the TBL is held out,
and $c_c=\tfrac12$ when Couette is held out. The geometry factor has no
fitted constant at all, so the pipe test is a genuine prediction.

| held-out family | test mean $R^2$ | test min |
|---|---|---|
| Channel (LM+UPM, 9 profiles; incl. $Re_\tau=5200$ extrapolation) | 0.99611 | 0.99069 |
| Pipe (4) | 0.99653 | 0.99035 |
| TBL (10) | 0.98874 | 0.98381 |
| Couette (3) | 0.98726 | 0.97896 |

LOFO parameter ranges are tight: $a_1=0.160$–$0.162$, $E_0=0.1402$–$0.1414$,
$a=3.85$–$3.94$, $c_c=0.535$–$0.563$ (when fitted), growth
$G_0=14.6$–$15.6$, $r_g=1.86$–$1.90$, $p_g=0.94$–$1.01$, $q_g=0.564$–$0.572$
(when fitted); $r_p=2.28$–$2.62$ and $w=0.36$–$0.68$ are the least identified.

*Honesty note.* The functional form was developed from budget diagnostics on
all four families; LOFO therefore validates the frozen structure and
constants against family-level extrapolation, not a form invented blind.

**Asymptotics.** Near wall $P/\varepsilon\sim0.0042\,y^{+3}(1+c_1y^{+2}+\dots)$
(DNS $P/\varepsilon/y^{+3}=0.0045$–$0.0055$ for $y^+<3$, matched within
$\sim5\%$); channel/pipe centre $\propto(1-\eta)^2$ with coefficients
$15.0$ / $12.2$ (DNS $13$–$16$ / $11$–$13$); Couette centre tends to the
finite core value $B(1-c_c\tanh^2(Re_\tau/300))$; TBL edge decays through
$\tau\to0$ in both the wake and growth factors. The formula is dimensionless
throughout: every input is a ratio in wall units.

---

## 4. Ablations and the minimal physical inputs

Each variant **refit** on all 26 profiles (`universal_ablation.py`):

| variant | mean $R^2$ | most affected family |
|---|---|---|
| Full | 0.99540 | — |
| no $V^+$ (growth off) | 0.91454 | TBL 0.84477 |
| $\tau$ only (no $V^+$, no $m$) | 0.90429 | TBL 0.82868 |
| $\tau:=1-\eta$ everywhere | 0.95129 | Couette 0.72547 |
| wake argument $:=1-\eta$ | 0.96192 | Couette 0.71252 |
| no core-import factor | 0.98805 | Couette 0.92100 |
| no log-crest bump | 0.99227 | Channel 0.99310 |
| no geometry factor | 0.99336 | Pipe 0.98688 |
| constant peak (no $\tau_p$ law) | 0.99524 | (peak heights only) |

Two reduction tests:

- **$V^+(\eta)\to$ scalar $V_e^+$:** replacing the whole $V^+$ profile by its
  edge (entrainment) value and refitting gives $0.99546$ (the fitted
  $\eta^{2.40}$ absorbs the near-universal ZPG shape $V^+\approx V_e^+\eta^{1.4}$).
  So with calibrated constants the development input is one number,
  $V_e^+$ ($0.048$–$0.067$ for the KTH stations). For a-priori prediction of an
  unseen *family*, the $V^+(\eta)$ profile with the $2/\kappa^2$ prior is more
  robust (LOFO TBL $0.98874$ vs $0.97237$ for the scalar with a prior).
- **$\tau(\eta)\to$ prescribed shape:** using the analytic parallel-flow stress
  plus a universal ZPG shape $1-\eta^{3/2}$ drops the TBL to $0.96751$
  (LOFO $0.94245$). The actual total-stress distribution of a developing layer
  is therefore a *necessary* input at the $0.99$ level; it cannot be replaced
  by $\eta$, $Re_\tau$, and $\alpha$ alone.

**Minimal input set.**
$\big\{\,y^+,\ \eta,\ Re_\tau,\ \tau_{tot}(\eta),\ V^+(\eta)\ \text{(or }V_e^+\text{)},\ m\,\big\}$,
where for parallel flows $\tau_{tot}=1-\alpha\eta$ (one number, $\alpha$) and
$V^+=0$. No family label is used anywhere.

---

## 5. Limitations

- Largest residuals: Couette $Re_\tau=500$ log crest (under-predicted by
  $\approx0.09$ near $\eta=0.35$) and core; Couette $Re_\tau=93$ centre
  ($+0.11$: at this $Re_\tau$ the two inner layers overlap and there is no log
  layer); the $Re_\tau=5200$ channel crest is placed slightly too far out
  ($y_c=721$ vs DNS crest $\approx327$, error $-0.07$ at $y^+=258$). A
  crest-centre exponent $Re^{1/4}$ fixes the channel but worsens held-out
  Couette flow, so the LOFO-selected $\sqrt{100Re_\tau}$ was kept.
- Only ZPG boundary layers are in the data. Because the formula takes
  $\tau(\eta)$ as an input, an adverse/favourable-pressure-gradient layer is a
  well-posed extrapolation (its stress shape and $V^+$ change), but it is
  untested here.
- Couette $Re_\tau=220$ has an anomalously weak core import in the DNS
  ($Re_\tau(\varepsilon-P)_{centre}=0.45$ vs $\approx0.8$–$1.0$ for
  $Re_\tau=93,500$ channels $\approx1.08$, pipes $\approx1.58\approx1.08(1+m/2)$);
  no smooth descriptor law captures that single profile exactly.

## 6. Files

- `universal_pe_model.py` — frozen formula + evaluation table (run it).
- `universal_model4.py` — fitting code used for the all-data fit.
- `universal_lofo4.py` — leave-one-family-out validation.
- `universal_ablation.py` — refit ablations / minimal-input study.
- `universal_descriptors.py` — builds $\tau(\eta)$, $V^+(\eta)$, $m$, $V_e^+$
  for the 26 profiles (on top of `budget_loader.py`).
- `universal_pe_profiles.pdf/png` — representative profiles
  (LM_5200, KTH_4060, Pipe_1000, Cou_500).
