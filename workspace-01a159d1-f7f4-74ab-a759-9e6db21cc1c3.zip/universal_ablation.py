#!/usr/bin/env python3
"""Ablation / minimal-input study for the U4 universal P/eps model.
Each variant is REFIT on all 26 profiles (same mask/objective), so drops in R2
measure genuine necessity, not just sensitivity to frozen constants.
"""
import numpy as np
from scipy.optimize import least_squares
from universal_descriptors import augment_profiles
import universal_model4 as um

profs = um.add_groups(augment_profiles())
LN1000 = um.LN1000

def predict_abl(p, x, o):
    a1, a2, bexp, bwave, E0, rp, Einf, wbump, a, cc, G0, rg, pg, qg = x
    Re = p["re_tau"]; lnRe = np.log(Re)
    eta_c = np.clip(p["eta"], 0, 1.05)
    tau = np.clip(p["tau"], 0, 1)
    if o.get("tau_linear"):
        tau = np.clip(1 - eta_c, 0, 1)
    tau_p = float(np.interp(12.0 / Re, p["eta"], tau if o.get("tau_linear") else np.clip(p["tau"],0,1)))
    if o.get("tau_linear"):
        tau_p = max(0.0, 1 - 12.0 / Re)
    if o.get("no_peaklaw"):
        tau_p = 1.0
    eps_pk = E0 * max(tau_p, 1e-9) ** rp
    ppeak = tau_p**2 / (4 * eps_pk)
    F0 = um.F_in(p["yp"], um.c1_for_peak(ppeak, a1, a2, bexp, bwave), a1, a2, bexp, bwave)
    yc = np.sqrt(100.0 * Re)
    Ec = 0.0 if o.get("no_crest") else um.Ec_of_Re(Re, Einf)
    B = F0 + Ec * um.Lbump(p["yp"], yc, wbump)
    warg = np.clip(1 - eta_c, 0, 1) if o.get("wtau_eta") else tau
    Wtau = np.tanh(a * warg) ** 2 / np.tanh(a) ** 2
    cc_eff = 0.0 if o.get("no_core") else cc
    Wcore = 1 - cc_eff * np.tanh(p["yp"] / 300.0) ** 2 * (eta_c ** 2) * (tau ** 2)
    Wgeo = 1.0 if o.get("no_geo") else 1.0 / (1.0 + p["mgeo"] * eta_c / 4.0)
    if o.get("no_V"):
        G = 0.0
    else:
        edge = np.tanh(a * (tau ** qg)) ** 2
        G = G0 * p["Vmean"] * (lnRe / LN1000) ** rg * (eta_c ** pg) * edge
    return B * Wtau * np.clip(Wcore, 0, None) * Wgeo + G

def fit_abl(o, x0=um.X0):
    # Freeze parameters that the ablation makes irrelevant (zero Jacobian otherwise).
    free = np.ones(len(x0), dtype=bool)
    if o.get("no_V"): free[10:14] = False       # G0, rg, pg, qg
    if o.get("no_core"): free[9] = False        # cc
    if o.get("no_crest"): free[[6, 7]] = False  # Einf, wbump
    if o.get("no_peaklaw"): free[5] = False     # rp
    xf = x0.copy()
    def resid(z):
        x = xf.copy(); x[free] = z
        out = []
        for p in profs:
            pr = predict_abl(p, x, o)
            m = um.mask_of(p)
            out.append((pr[m] - p["pe"][m]) / np.sqrt(m.sum()))
        return np.concatenate(out)
    res = least_squares(resid, x0[free], bounds=(um.LO[free], um.HI[free]),
                        max_nfev=1000, ftol=1e-11, xtol=1e-11)
    x = xf.copy(); x[free] = res.x
    return x

def eval_abl(x, o):
    sc = {}
    for p in profs:
        sc[p["id"]] = um.r2(p, predict_abl(p, x, o))
    return sc

VARIANTS = [
    ("FULL (tau, V, m)", {}),
    ("no V / no growth term", {"no_V": True}),
    ("no geometry factor", {"no_geo": True}),
    ("no core-import factor", {"no_core": True}),
    ("no log crest bump", {"no_crest": True}),
    ("constant peak (no tau_p law)", {"no_peaklaw": True}),
    ("tau := 1-eta everywhere", {"tau_linear": True}),
    ("W argument := 1-eta (classic wake)", {"wtau_eta": True}),
    ("tau only (no V, no m)", {"no_V": True, "no_geo": True}),
]

if __name__ == "__main__":
    print(f"{'variant':38s} {'mean':>8s} {'min':>8s} | {'Chan':>7s} {'Pipe':>7s} {'TBL':>7s} {'Cou':>7s}", flush=True)
    for name, o in VARIANTS:
        print(f"... fitting {name}", flush=True)
        x = fit_abl(o)
        sc = eval_abl(x, o)
        vals = np.array(list(sc.values()))
        fam = {}
        for g in ["Channel","Pipe","TBL","Couette"]:
            fam[g] = np.mean([sc[p["id"]] for p in profs if p["group"] == g])
        print(f"{name:38s} {vals.mean():8.5f} {vals.min():8.5f} | {fam['Channel']:7.5f} {fam['Pipe']:7.5f} {fam['TBL']:7.5f} {fam['Couette']:7.5f}", flush=True)
