#!/usr/bin/env python3
"""
Cross-check of ALL existing models against the measured budget physics on the
26 DNS profiles: Oxford_PySR, Oxford_M16, SEMBAN-1D-5p/6p, SEMBAN-2D-7pHyp/9p, SEMBAN-B.
Diagnostics: overall R2, and physics-feature errors (peak / trough / crest / outer).
"""
import numpy as np
from budget_loader import load_all_budgets
import semban_b_final as sb
from semban_b_final import predict as pred_b
fam_of = {"LM":"ch", "UPM":"ch", "KTH":"tbl", "Pipe":"pipe", "Cou":"cou"}
from verify_higher_space_closures import ox_pysr, ox_m16
from verify_minimal_physics_closures import (
    f_semban_1d_5p, f_semban_1d_6p, f_semban_2d_7phyp, f_semban_2d_9p
)

def r2_of(pred, pe): return 1.0 - np.sum((pred-pe)**2)/np.sum((pe-pe.mean())**2)

MODELS = [
    ("Oxford_PySR",      lambda yp, eta, p: ox_pysr(yp)),
    ("Oxford_M16",       lambda yp, eta, p: ox_m16(yp)),
    ("SEMBAN-1D-5p",     lambda yp, eta, p: f_semban_1d_5p(yp)),
    ("SEMBAN-1D-6p",     lambda yp, eta, p: f_semban_1d_6p(yp)),
    ("SEMBAN-2D-7pHyp",  lambda yp, eta, p: f_semban_2d_7phyp(yp, eta)),
    ("SEMBAN-2D-9p",     lambda yp, eta, p: f_semban_2d_9p(yp, eta)),
    ("SEMBAN-B",         None),  # special-cased
]

def features(pred, pe, yp, eta):
    m = yp < 30
    pk = pred[m].max() - pe[m].max()
    m2 = (yp >= 30) & (yp <= 120)
    tr = pred[m2].min() - pe[m2].min() if m2.sum() > 2 else np.nan
    m3 = (yp >= 130) & (eta <= 0.75)
    cr = pred[m3].max() - pe[m3].max() if m3.sum() > 2 else np.nan
    m4 = eta >= 0.5
    out = np.median(np.abs(pred[m4]-pe[m4])) if m4.sum() > 2 else np.nan
    return pk, tr, cr, out

if __name__ == "__main__":
    profs = load_all_budgets()
    by = {p["id"]: p for p in profs}
    # rebuild SEMBAN-B exactly as in semban_b_final.__main__
    sb.fit_ch_crest_laws([by["LM_1000"], by["LM_5200"]])
    P_B = {"ch": dict(peak=sb.peak_ch)}
    P_B["tbl"] = sb.fit_on([by["KTH_4060"]], "tbl",
                           dict(peak=1.758, e0=0.93, we=0.035, Et=0.17, etc=0.58, wt=0.28),
                           ["e0","we","Et","etc","wt"])
    P_B["pipe"] = sb.fit_on([by["Pipe_550"]], "pipe",
                            dict(peak=1.785, g0p=0.10, g1p=4.2, Ep=0.05, ycp=230.0),
                            ["g0p","g1p","Ep","ycp"])
    P_B["cou"] = sb.fit_on([by["Cou_220"], by["Cou_500"]], "cou",
                           dict(peak=1.745, kcore=0.15, etc2=0.35, Ec=0.10, ycc=190.0),
                           ["kcore","etc2","Ec","ycc"])
    print("="*112)
    print("CROSS-CHECK OF EXISTING MODELS ON ALL 26 DNS BUDGET PROFILES (physics-feature diagnostics)")
    print("="*112)
    summary = {}
    for name, fn in MODELS:
        r2s, pks, trs, crs, outs = [], [], [], [], []
        fam_r2 = {}
        for p in profs:
            pe = p["P"]/p["eps"]
            if name == "SEMBAN-B":
                pred = pred_b(p["yp"], p["eta"], p["re_tau"], fam_of[p["family"]], P_B[fam_of[p["family"]]])
            else:
                pred = fn(p["yp"], p["eta"], p)
            r2 = r2_of(pred, pe)
            r2s.append(r2)
            fam_r2.setdefault(p["family"], []).append(r2)
            pk, tr, cr, out = features(pred, pe, p["yp"], p["eta"])
            pks.append(abs(pk)); trs.append(abs(tr))
            if not np.isnan(cr): crs.append(abs(cr))
            if not np.isnan(out): outs.append(abs(out))
        summary[name] = (np.mean(r2s), np.min(r2s), np.mean(pks), np.mean(trs), np.mean(crs) if crs else np.nan, np.mean(outs) if outs else np.nan, {k: np.mean(v) for k,v in fam_r2.items()})
        s = summary[name]
        fam_str = " ".join([f"{k}={v:.3f}" for k,v in sorted(s[6].items())])
        print(f"\n{name}")
        print(f"  R2 mean={s[0]:.5f} min={s[1]:.5f} | family means: {fam_str}")
        print(f"  |peak_err|={s[2]:.3f} |trough_err|={s[3]:.3f} |crest_err|={s[4]:.3f} |outer_err|={s[5]:.3f}")
    print()
    print("="*112)
    print(f"{'Model':16s} {'R2_mean':>8s} {'R2_min':>8s} {'LM/UPM':>8s} {'KTH_TBL':>8s} {'Pipe':>8s} {'Cou':>8s} {'|pk|':>6s} {'|tr|':>6s} {'|cr|':>6s} {'|out|':>6s}")
    for name, s in summary.items():
        fam = s[6]
        lm = np.mean([fam.get("LM", np.nan), fam.get("UPM", np.nan)])
        print(f"{name:16s} {s[0]:8.5f} {s[1]:8.5f} {lm:8.5f} {fam.get('KTH',np.nan):8.5f} {fam.get('Pipe',np.nan):8.5f} {fam.get('Cou',np.nan):8.5f} {s[2]:6.3f} {s[3]:6.3f} {s[4]:6.3f} {s[5]:6.3f}")
