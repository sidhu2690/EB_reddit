#!/usr/bin/env python3
"""
Unified loader for full TKE-budget DNS profiles across all 5 flow families.
Each entry: dict(id, family, re_tau, eta, yp, P, Tt, Tp, Dv, eps, conv)
Conventions (all wall units, all positive-in-source convention):
    P    : production  (= -<u'v'> dU/dy)
    Tt   : turbulent transport  (divergence term, source>0)
    Tp   : pressure transport / pressure diffusion (source>0)
    Dv   : viscous diffusion (source>0)
    eps  : dissipation (positive)
    conv : streamwise convection (TBL only; 0 for channel/pipe/couette)
Budget identity:  P - eps + Tt + Tp + Dv + conv = 0
"""
import numpy as np
import glob, os, re

def _lm_budget(path, tag, family):
    d = np.loadtxt(path, comments="%")
    yd, yp, P, Tt, Dv, Tp, eps = d[:,0], d[:,1], d[:,2], d[:,3], d[:,4], d[:,6], d[:,7]
    # LM convention: Balance = P + Tt + Dv + PS + Tp - eps  (PS=0), so same as ours
    return dict(id=tag, family=family, re_tau=float(yp[-1]/max(yd[-1],1e-12)) if yd[-1]>0 else np.nan,
                eta=yd, yp=yp, P=P, Tt=Tt, Tp=Tp, Dv=Dv, eps=eps, conv=np.zeros_like(P),
                source="LM")

def _upm_budget(path, tag):
    d = np.loadtxt(path, comments="%")
    # cols: y/h, y+, dissip, produc, p-strain, p-diff, t-diff, v-diff, bal, tp-kbal
    yd, yp, eps_n, P, pstrain, Tp, Tt, Dv = d[:,0], d[:,1], d[:,2], d[:,3], d[:,4], d[:,5], d[:,6], d[:,7]
    eps = -eps_n  # UPM prints dissipation negative
    return dict(id=tag, family="UPM", re_tau=float(yp[-1]/max(yd[-1],1e-12)) if yd[-1]>0 else np.nan,
                eta=yd, yp=yp, P=P, Tt=Tt, Tp=Tp, Dv=Dv, eps=eps, conv=np.zeros_like(P),
                source="UPM")

def _kth_budget(path, tag):
    rows = []
    re_tau = np.nan
    with open(path) as f:
        for line in f:
            m = re.search(r"Re_\{\\tau\}\s+=\s+([0-9.]+)", line)
            if m:
                re_tau = float(m.group(1))
            if line.startswith("%") or not line.strip():
                continue
            parts = line.split()
            if len(parts) >= 9:
                try:
                    rows.append([float(x) for x in parts[:9]])
                except ValueError:
                    continue
    d = np.array(rows)
    yd, yp, conv, P, eps_n, Tt, Tp, Dv, res = d[:,0], d[:,1], d[:,2], d[:,3], d[:,4], d[:,5], d[:,6], d[:,7], d[:,8]
    eps = -eps_n  # KTH prints dissipation negative
    return dict(id=tag, family="KTH", re_tau=re_tau, eta=yd, yp=yp, P=P, Tt=Tt, Tp=Tp, Dv=Dv,
                eps=eps, conv=conv, source="KTH")

def _pipe_budget(tag, re_tau_nominal):
    # TKE budget = (RR + ZZ + TT)/2 for each budget term
    def load_term(kind):
        d = np.loadtxt(f"/home/user/dns_data/el_khoury_pipe/{tag}_{kind}_Budget.dat", comments="%")
        # cols: (1-r), y+, Production, TD, PD, PS, VD, D(neg)
        return d
    rr, zz, tt = load_term("RR"), load_term("ZZ"), load_term("TT")
    yp = tt[:,1]
    yd = 1.0 - tt[:,0]   # file gives (1-r) = y/R from wall? col0 = 1-r where r=R-y... actually 1-r = y/R
    # At first row col0=1.0 and y+=Re_tau -> 1-r = 1 means r=0?? If col0 = 1-r and first row is 1.0 with y+=Re_tau:
    # that means the file lists from centerline? No: y+=999 at col0=1 -> col0 = y/R. So y/R = col0.
    yd = rr[:,0]
    P   = 0.5*(rr[:,2] + zz[:,2] + tt[:,2])
    Tt  = 0.5*(rr[:,3] + zz[:,3] + tt[:,3])
    Tp  = 0.5*(rr[:,4] + zz[:,4] + tt[:,4])
    Dv  = 0.5*(rr[:,6] + zz[:,6] + tt[:,6])
    eps = -0.5*(rr[:,7] + zz[:,7] + tt[:,7])
    # Sort ascending y+
    order = np.argsort(yp)
    return dict(id=f"Pipe_{tag}", family="Pipe", re_tau=float(np.max(yp)), eta=yd[order], yp=yp[order],
                P=P[order], Tt=Tt[order], Tp=Tp[order], Dv=Dv[order], eps=eps[order],
                conv=np.zeros_like(P[order]), source="EK")

def load_all_budgets():
    profs = []
    for tag in ["0180","0550","1000","2000","5200"]:
        profs.append(_lm_budget(f"/home/user/dns_data/LM_Channel_{tag}_RSTE_k_prof.dat", f"LM_{int(tag)}", "LM"))
    for tag in ["0093","0220","0500"]:
        profs.append(_lm_budget(f"/home/user/dns_data/LM_Couette_R{tag}_020PI_RSTE_k_prof.dat", f"Cou_{int(tag)}", "Cou"))
    for tag in ["180","550","950","2000"]:
        profs.append(_upm_budget(f"/home/user/dns_data/upm_channel/UPM_Re{tag}_balance_kbal.dat", f"UPM_{tag}"))
    for tag in ["0670","1000","1410","2000","2540","3030","3270","3630","3970","4060"]:
        profs.append(_kth_budget(f"/home/user/dns_data/kth_tbl/bud_{tag}_dns_k.prof", f"KTH_{tag}"))
    for tag in ["180","360","550","1000"]:
        profs.append(_pipe_budget(tag, tag))
    return profs

if __name__ == "__main__":
    profs = load_all_budgets()
    print(f"Loaded {len(profs)} budget profiles")
    for p in profs:
        # verify budget identity P - eps + Tt + Tp + Dv + conv = 0
        res = p["P"] - p["eps"] + p["Tt"] + p["Tp"] + p["Dv"] + p["conv"]
        print(f"{p['id']:10s} {p['family']:5s} Re_tau={p['re_tau']:7.1f} npts={len(p['yp']):5d} "
              f"max|budget residual|={np.max(np.abs(res)):.2e} eps_w={p['eps'][0]:.4f}")
