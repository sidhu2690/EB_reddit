#!/usr/bin/env python3
"""Generate the representative-profile figure used in the SEMBAN-B short paper."""
import numpy as np
import matplotlib.pyplot as plt
from budget_loader import load_all_budgets
import semban_b_final as sb

profs = load_all_budgets()
by = {p["id"]: p for p in profs}

# Reproduce the frozen SEMBAN-B constants used in semban_b_final.py.
sb.fit_ch_crest_laws([by["LM_1000"], by["LM_5200"]])
P = {"ch": dict(peak=sb.peak_ch)}
P["tbl"] = sb.fit_on([by["KTH_4060"]], "tbl",
                     dict(peak=1.758, e0=0.93, we=0.035, Et=0.17, etc=0.58, wt=0.28),
                     ["e0", "we", "Et", "etc", "wt"])
P["pipe"] = sb.fit_on([by["Pipe_550"]], "pipe",
                      dict(peak=1.785, g0p=0.10, g1p=4.2, Ep=0.05, ycp=230.0),
                      ["g0p", "g1p", "Ep", "ycp"])
P["cou"] = sb.fit_on([by["Cou_220"], by["Cou_500"]], "cou",
                     dict(peak=1.745, kcore=0.15, etc2=0.35, Ec=0.10, ycc=190.0),
                     ["kcore", "etc2", "Ec", "ycc"])

fam_of = {"LM": "ch", "UPM": "ch", "KTH": "tbl", "Pipe": "pipe", "Cou": "cou"}
sel = [
    ("LM_5200", "Channel, $Re_\\tau=5186$"),
    ("KTH_4060", "ZPG boundary layer, $Re_\\tau=1272$"),
    ("Pipe_1000", "Pipe, $Re_\\tau=999$"),
    ("Cou_500", "Plane Couette, $Re_\\tau=503$"),
]

fig, axes = plt.subplots(2, 2, figsize=(7.2, 5.0), sharex=False, sharey=True)
for ax, (pid, title) in zip(axes.ravel(), sel):
    p = by[pid]
    fam = fam_of[p["family"]]
    pe = p["P"] / p["eps"]
    pred = sb.predict(p["yp"], p["eta"], p["re_tau"], fam, P[fam])
    m = p["yp"] >= 0.15
    ax.plot(p["yp"][m], pe[m], color="0.35", lw=1.15, label="DNS")
    ax.plot(p["yp"][m], pred[m], color="#2878b5", lw=1.35, label="SEMBAN-B")
    ax.set_xscale("log")
    ax.set_xlim(0.15, max(10.0, np.max(p["yp"][m]) * 1.03))
    ax.set_ylim(-0.08, 2.02)
    ax.set_title(title, fontsize=9)
    ax.grid(True, which="major", alpha=0.25, lw=0.5)
    ax.tick_params(labelsize=8)
    r2 = sb.r2_of(pred, pe)
    ax.text(0.04, 0.91, f"$R^2={r2:.4f}$", transform=ax.transAxes, fontsize=8,
            bbox=dict(boxstyle="round,pad=0.22", fc="white", ec="0.75", alpha=0.9))

for ax in axes[-1, :]:
    ax.set_xlabel("$y^+$", fontsize=9)
for ax in axes[:, 0]:
    ax.set_ylabel("$P/\epsilon$", fontsize=9)
axes[0, 0].legend(loc="lower right", fontsize=8, framealpha=0.95)
fig.tight_layout()
fig.savefig("/home/user/semban_b_profiles.pdf", bbox_inches="tight")
fig.savefig("/home/user/semban_b_profiles.png", dpi=250, bbox_inches="tight")
print("saved /home/user/semban_b_profiles.pdf and .png")
