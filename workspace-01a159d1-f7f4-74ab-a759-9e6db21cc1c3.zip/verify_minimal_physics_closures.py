#!/usr/bin/env python3
"""
Verification of the Minimal Physics-Grounded SEMBAN Hierarchy (1D: 3p-6p, 2D: 5p-9p)
Strictly trained on Lee & Moser (2015) Channel DNS at Re_tau in {1000, 5200}
and evaluated frozen across all 26 canonical DNS profiles.
"""
import numpy as np
from verify_higher_space_closures import (
    ch_tr, ch_ho, upm_all, kth_all, pipe_all, cou_all,
    get_inner_slice, get_full_slice, get_sub_slice, r2_score,
    ox_pysr as f_ox_pysr, ox_m16 as f_ox_m16,
    semban_1d_prev as f_semban_1d_prev, semban_2d_prev as f_semban_2d_prev
)

# ==============================================================================
# FROZEN 1D MINIMAL PHYSICS-GROUNDED CLOSURES (k = 3, 4, 5, 6)
# ==============================================================================

# 1. SEMBAN-1D-3p (k = 3: Ultra-Minimal Scale-Coupled Closure, c1 = 1.5*b1^2, b2 = 0.5*b1^2)
P_1D_3P = np.array([0.16172470, 0.00651322, 0.20015770])
def f_semban_1d_3p(yp, p=P_1D_3P):
    a1, a2, b1 = p
    G = np.tanh(a1 * yp + a2 * (yp ** 2)) ** 3
    T = np.tanh(0.5 * (b1 ** 2) * yp)
    return G * (1.0 - (T ** 5) * (1.0 - T ** 2) + 1.5 * ((b1 * yp) ** 2) * np.exp(-b1 * yp))

# 2. SEMBAN-1D-4p (k = 4: Scale-Coupled Flux-Divergence Closure, b2 = 0.5*b1^2)
# Exact same parameter count (k = 4) as Oxford_PySR and Oxford_M16!
P_1D_4P = np.array([0.16243452, 0.00585892, 0.06356223, 0.20247138])
def f_semban_1d_4p(yp, p=P_1D_4P):
    a1, a2, c1, b1 = p
    G = np.tanh(a1 * yp + a2 * (yp ** 2)) ** 3
    T = np.tanh(0.5 * (b1 ** 2) * yp)
    return G * (1.0 - (T ** 5) * (1.0 - T ** 2) + c1 * (yp ** 2) * np.exp(-b1 * yp))

# 3. SEMBAN-1D-5p (k = 5: Asymptotic Equilibrium Flux-Divergence Closure, c0 = 1)
P_1D_5P = np.array([0.16234303, 0.00596653, 0.06272513, 0.20161904, 0.02065071])
def f_semban_1d_5p(yp, p=P_1D_5P):
    a1, a2, c1, b1, b2 = p
    G = np.tanh(a1 * yp + a2 * (yp ** 2)) ** 3
    T = np.tanh(b2 * yp)
    return G * (1.0 - (T ** 5) * (1.0 - T ** 2) + c1 * (yp ** 2) * np.exp(-b1 * yp))

# 4. SEMBAN-1D-5pHyp (k = 5: Scale-Coupled Hyperbolic-Beta Closure, b2 = b1^2 / 3)
P_1D_5PHYP = np.array([0.15974560, 0.00636751, 1.04681888, 0.05782046, 0.19785307])
def f_semban_1d_5phyp(yp, p=P_1D_5PHYP):
    a1, a2, c0, c1, b1 = p
    G = np.tanh(a1 * yp + a2 * (yp ** 2)) ** 3
    T = np.tanh(((b1 ** 2) / 3.0) * yp)
    return G * (c0 * (1.0 - (T ** 2) * (1.0 - T)) + c1 * (yp ** 2) * np.exp(-b1 * yp))

# 5. SEMBAN-1D-6p (k = 6: Hyperbolic-Beta Non-Equilibrium Closure)
P_1D_6P = np.array([0.15971771, 0.00647237, 1.04557679, 0.05701096, 0.19674992, 0.01318698])
def f_semban_1d_6p(yp, p=P_1D_6P):
    a1, a2, c0, c1, b1, b2 = p
    G = np.tanh(a1 * yp + a2 * (yp ** 2)) ** 3
    T = np.tanh(b2 * yp)
    return G * (c0 * (1.0 - (T ** 2) * (1.0 - T)) + c1 * (yp ** 2) * np.exp(-b1 * yp))


# ==============================================================================
# FROZEN 2D MINIMAL PHYSICS-GROUNDED CLOSURES (k = 5, 6, 7, 8, 9 — ZERO DIVISIONS)
# ==============================================================================

# 1. SEMBAN-2D-5p (k = 5: Scale-Coupled Flux-Divergence + 1p Centerline Symmetry Wake)
P_2D_5P = np.array([0.16239265, 0.00584598, 0.06389575, 0.20261156, 3.97757724])
def f_semban_2d_5p(yp, yd, p=P_2D_5P):
    a1, a2, c1, b1, g1 = p
    G = np.tanh(a1 * yp + a2 * (yp ** 2)) ** 3
    T = np.tanh(0.5 * (b1 ** 2) * yp)
    W = np.tanh(g1 * (1.0 - yd)) ** 2
    return G * (1.0 - (T ** 5) * (1.0 - T ** 2) + c1 * (yp ** 2) * np.exp(-b1 * yp)) * W

# 2. SEMBAN-2D-6pHyp (k = 6: Scale-Coupled Hyperbolic-Beta [b2=b1^2/3] + 1p Wake)
P_2D_6PHYP = np.array([0.15959029, 0.00636796, 1.04977685, 0.05816037, 0.19812973, 3.68202534])
def f_semban_2d_6phyp(yp, yd, p=P_2D_6PHYP):
    a1, a2, c0, c1, b1, g1 = p
    G = np.tanh(a1 * yp + a2 * (yp ** 2)) ** 3
    T = np.tanh(((b1 ** 2) / 3.0) * yp)
    W = np.tanh(g1 * (1.0 - yd)) ** 2
    return G * (c0 * (1.0 - (T ** 2) * (1.0 - T)) + c1 * (yp ** 2) * np.exp(-b1 * yp)) * W

# 3. SEMBAN-2D-7pHyp (k = 7: Scale-Coupled Hyperbolic-Beta [b2=b1^2/3] + 2p Wake)
P_2D_7PHYP = np.array([0.15927131, 0.00638149, 1.05493579, 0.05799834, 0.19854718, 0.07759239, 3.92368480])
def f_semban_2d_7phyp(yp, yd, p=P_2D_7PHYP):
    a1, a2, c0, c1, b1, g0, g1 = p
    G = np.tanh(a1 * yp + a2 * (yp ** 2)) ** 3
    T = np.tanh(((b1 ** 2) / 3.0) * yp)
    W = (1.0 - g0 * yd) * (np.tanh(g1 * (1.0 - yd)) ** 2)
    return G * (c0 * (1.0 - (T ** 2) * (1.0 - T)) + c1 * (yp ** 2) * np.exp(-b1 * yp)) * W

# 4. SEMBAN-2D-8pHyp (k = 8: Scale-Coupled Hyperbolic-Beta + Re_tau Buffer Shift + 2p Wake)
P_2D_8PHYP = np.array([0.15917868, 0.00635206, 1.05543797, 0.07546103, -0.00226292, 0.19860257, 0.08404612, 3.94459464])
def f_semban_2d_8phyp(yp, yd, p=P_2D_8PHYP):
    a1, a2, c0, c1, d1, b1, g0, g1 = p
    G = np.tanh(a1 * yp + a2 * (yp ** 2)) ** 3
    T = np.tanh(((b1 ** 2) / 3.0) * yp)
    ln_ret = np.log(np.maximum(yp / np.maximum(yd, 1e-12), 1.0))
    W = (1.0 - g0 * yd) * (np.tanh(g1 * (1.0 - yd)) ** 2)
    return G * (c0 * (1.0 - (T ** 2) * (1.0 - T)) + (c1 + d1 * ln_ret) * (yp ** 2) * np.exp(-b1 * yp)) * W

# 5. SEMBAN-2D-9p (k = 9: Uncoupled Hyperbolic-Beta + Re_tau Buffer Shift + 2p Wake)
P_2D_9P = np.array([0.15915517, 0.00639415, 1.05582646, 0.07536615, -0.00225969, 0.19865122, 0.01314632, 0.07787200, 3.93232872])
def f_semban_2d_9p(yp, yd, p=P_2D_9P):
    a1, a2, c0, c1, d1, b1, b2, g0, g1 = p
    G = np.tanh(a1 * yp + a2 * (yp ** 2)) ** 3
    T = np.tanh(b2 * yp)
    ln_ret = np.log(np.maximum(yp / np.maximum(yd, 1e-12), 1.0))
    W = (1.0 - g0 * yd) * (np.tanh(g1 * (1.0 - yd)) ** 2)
    return G * (c0 * (1.0 - (T ** 2) * (1.0 - T)) + (c1 + d1 * ln_ret) * (yp ** 2) * np.exp(-b1 * yp)) * W


if __name__ == "__main__":
    print("=" * 124)
    print("1D INNER-LAYER CLOSURE PARETO HIERARCHY (k = 3 TO 7 PARAMETERS, TRAINED STRICTLY ON LM Re_tau IN {1000, 5200})")
    print("=" * 124)
    print(f"{'Model Name':34s} | {'k':2s} | {'Train(2)':8s} | {'HO_LM(3)':8s} | {'UPM(4)':8s} | {'KTH(10)':8s} | {'Pipe(4)':8s} | {'Cou(3)':8s} | {'Mean24':8s} | {'Sub_HO':7s} | {'Diss_HO':7s}")
    print("-" * 124)
    models_1d = [
        ("Oxford_PySR (2026)", 4, f_ox_pysr),
        ("Oxford_M16 (2026)", 4, f_ox_m16),
        ("SEMBAN-1D (Prev 7p)", 7, f_semban_1d_prev),
        ("SEMBAN-1D-3p (Scale-Coupled 3p)", 3, f_semban_1d_3p),
        ("SEMBAN-1D-4p (Scale-Coupled 4p)", 4, f_semban_1d_4p),
        ("SEMBAN-1D-5p (FluxDiv Eq 5p)", 5, f_semban_1d_5p),
        ("SEMBAN-1D-5pHyp (Coupled HypBeta)", 5, f_semban_1d_5phyp),
        ("SEMBAN-1D-6p (HypBeta NonEq 6p)", 6, f_semban_1d_6p),
    ]
    for name, k, fn in models_1d:
        tr = np.mean([r2_score(get_inner_slice(d)[4], fn(get_inner_slice(d)[0])) for d in ch_tr])
        ho = np.mean([r2_score(get_inner_slice(d)[4], fn(get_inner_slice(d)[0])) for d in ch_ho])
        upm = np.mean([r2_score(get_inner_slice(d)[4], fn(get_inner_slice(d)[0])) for d in upm_all])
        kth = np.mean([r2_score(get_inner_slice(d)[4], fn(get_inner_slice(d)[0])) for d in kth_all])
        pip = np.mean([r2_score(get_inner_slice(d)[4], fn(get_inner_slice(d)[0])) for d in pipe_all])
        cou = np.mean([r2_score(get_inner_slice(d)[4], fn(get_inner_slice(d)[0])) for d in cou_all])
        m24 = np.mean([r2_score(get_inner_slice(d)[4], fn(get_inner_slice(d)[0])) for d in (ch_ho + upm_all + kth_all + pipe_all + cou_all)])
        se_ho = np.mean([100.0 * np.mean(np.abs(fn(get_sub_slice(d)[0]) - get_sub_slice(d)[4]) / get_sub_slice(d)[4]) for d in ch_ho])
        dr_ho = np.mean([100.0 * (1.0 - np.sqrt(np.mean((get_inner_slice(d)[2]/np.maximum(fn(get_inner_slice(d)[0]), 1e-6) - get_inner_slice(d)[3])**2)) / np.sqrt(np.mean((get_inner_slice(d)[2] - get_inner_slice(d)[3])**2))) for d in ch_ho])
        print(f"{name:34s} | {k:2d} | {tr:8.5f} | {ho:8.5f} | {upm:8.5f} | {kth:8.5f} | {pip:8.5f} | {cou:8.5f} | {m24:8.5f} | {se_ho:6.2f}% | {dr_ho:6.2f}%")

    print("\n" + "=" * 141)
    print("2D FULL-DOMAIN CLOSURE PARETO HIERARCHY (k = 5 TO 10 PARAMETERS, ZERO DIVISIONS, ZERO ARBITRARY CONSTANTS)")
    print("=" * 141)
    print(f"{'Model Name':34s} | {'k':2s} | {'TrIn':7s} {'TrFl':7s} | {'HO_In':7s} {'HO_Fl':7s} | {'UPM_In':7s} {'UPM_Fl':7s} | {'KTH_In':7s} | {'Pip_In':7s} {'Pip_Fl':7s} | {'Mean21':7s} | {'Sub_HO':6s} | {'Diss_HO':7s}")
    print("-" * 141)
    models_2d = [
        ("SEMBAN-2D (Prev 10p)", 10, f_semban_2d_prev),
        ("SEMBAN-2D-5p (Coupled FluxDiv+W1)", 5, f_semban_2d_5p),
        ("SEMBAN-2D-6pHyp (Coupled Hyp+W1)", 6, f_semban_2d_6phyp),
        ("SEMBAN-2D-7pHyp (Coupled Hyp+W2)", 7, f_semban_2d_7phyp),
        ("SEMBAN-2D-8pHyp (Coupled+Re+W2)", 8, f_semban_2d_8phyp),
        ("SEMBAN-2D-9p (Uncoupled+Re+W2)", 9, f_semban_2d_9p),
    ]
    for name, k, fn in models_2d:
        tr_in = np.mean([r2_score(get_inner_slice(d)[4], fn(get_inner_slice(d)[0], get_inner_slice(d)[1])) for d in ch_tr])
        tr_fl = np.mean([r2_score(get_full_slice(d)[4], fn(get_full_slice(d)[0], get_full_slice(d)[1])) for d in ch_tr])
        ho_in = np.mean([r2_score(get_inner_slice(d)[4], fn(get_inner_slice(d)[0], get_inner_slice(d)[1])) for d in ch_ho])
        ho_fl = np.mean([r2_score(get_full_slice(d)[4], fn(get_full_slice(d)[0], get_full_slice(d)[1])) for d in ch_ho])
        up_in = np.mean([r2_score(get_inner_slice(d)[4], fn(get_inner_slice(d)[0], get_inner_slice(d)[1])) for d in upm_all])
        up_fl = np.mean([r2_score(get_full_slice(d)[4], fn(get_full_slice(d)[0], get_full_slice(d)[1])) for d in upm_all])
        kt_in = np.mean([r2_score(get_inner_slice(d)[4], fn(get_inner_slice(d)[0], get_inner_slice(d)[1])) for d in kth_all])
        pi_in = np.mean([r2_score(get_inner_slice(d)[4], fn(get_inner_slice(d)[0], get_inner_slice(d)[1])) for d in pipe_all])
        pi_fl = np.mean([r2_score(get_full_slice(d)[4], fn(get_full_slice(d)[0], get_full_slice(d)[1])) for d in pipe_all])
        m21 = np.mean([r2_score(get_inner_slice(d)[4], fn(get_inner_slice(d)[0], get_inner_slice(d)[1])) for d in (ch_ho + upm_all + kth_all + pipe_all)])
        se_ho = np.mean([100.0 * np.mean(np.abs(fn(get_sub_slice(d)[0], get_sub_slice(d)[1]) - get_sub_slice(d)[4]) / get_sub_slice(d)[4]) for d in ch_ho])
        dr_ho = np.mean([100.0 * (1.0 - np.sqrt(np.mean((get_inner_slice(d)[2]/np.maximum(fn(get_inner_slice(d)[0], get_inner_slice(d)[1]), 1e-6) - get_inner_slice(d)[3])**2)) / np.sqrt(np.mean((get_inner_slice(d)[2] - get_inner_slice(d)[3])**2))) for d in ch_ho])
        print(f"{name:34s} | {k:2d} | {tr_in:7.5f} {tr_fl:7.5f} | {ho_in:7.5f} {ho_fl:7.5f} | {up_in:7.5f} {up_fl:7.5f} | {kt_in:7.5f} | {pi_in:7.5f} {pi_fl:7.5f} | {m21:7.5f} | {se_ho:5.2f}% | {dr_ho:6.2f}%")
