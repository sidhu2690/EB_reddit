#!/usr/bin/env python3
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from universal_descriptors import augment_profiles
from universal_pe_model import predict_pe

profs = {p["id"]: p for p in augment_profiles()}
panels = [("LM_5200", "Channel, $Re_\\tau=5186$"),
          ("KTH_4060", "ZPG TBL, $Re_\\tau=1272$"),
          ("Pipe_1000", "Pipe, $Re_\\tau=999$"),
          ("Cou_500", "Couette, $Re_\\tau=503$")]
fig, axes = plt.subplots(2, 2, figsize=(8.2, 6.4), sharey=True)
for ax, (pid, title) in zip(axes.ravel(), panels):
    p = profs[pid]
    pred = predict_pe(p["yp"], p["eta"], p["re_tau"], p["tau"], p["Vmean"], p["mgeo"])
    m = (p["eta"] <= 1.05) & (p["yp"] >= 0.8)
    pe = p["pe"]
    mm = (p["eta"] <= 1.05) & (p["yp"] >= 0.05)
    r2 = 1 - np.sum((pred[mm]-pe[mm])**2)/np.sum((pe[mm]-pe[mm].mean())**2)
    ax.semilogx(p["yp"][m], pe[m], ".", ms=3.2, color="0.25", label="DNS")
    ax.semilogx(p["yp"][m], pred[m], "-", lw=1.7, color="#b2182b", label="Universal formula")
    ax.set_title(f"{title}  ($R^2={r2:.4f}$)", fontsize=10)
    ax.set_xlabel("$y^+$")
    ax.set_ylim(-0.08, 1.95)
    ax.grid(True, which="both", alpha=0.18, lw=0.5)
axes[0,0].set_ylabel("$P/\\varepsilon$")
axes[1,0].set_ylabel("$P/\\varepsilon$")
axes[0,0].legend(fontsize=8, frameon=False, loc="lower left")
fig.tight_layout()
fig.savefig("/home/user/universal_pe_profiles.pdf")
fig.savefig("/home/user/universal_pe_profiles.png", dpi=200)
print("saved universal_pe_profiles.pdf/png")
