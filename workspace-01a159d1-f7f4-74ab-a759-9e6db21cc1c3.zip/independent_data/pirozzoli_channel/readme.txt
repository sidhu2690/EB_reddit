Flow statistics for turbulent Poiseuille flow at various Reynolds numbers are reported in this folder.
The reference source is: M. Bernardini, S. Pirozzoli, P. Orlandi, "Velocity statistics in turbulent channel flow up to Retau=4000" Journal of Fluid Mechanics Volume 742, March 2014, Pages 171-191
List of files:
* chann*dat : distribution of main flow statistics (e.g. mean and fluctuating velocities, vorticity rms)
* kbudg*dat : turbulence kinetic energy budget terms
* diagnostics*dat : diagnostic functions and additional indicators (partial header)
* relambda*dat : distribution of Kolmogorov length scale and Re_lambda (partial header)
* cf_Poiseuille.dat : friction coefficient as a function of Reynolds number
* upmax_Poiseuille.dat : peak Reynolds stresses as a function of Reynolds number 
