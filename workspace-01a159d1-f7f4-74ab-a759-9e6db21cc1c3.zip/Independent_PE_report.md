# Independent-flow test of the frozen universal \(P/\varepsilon\) formula

**Date:** 20 October 2026  
**Model:** frozen U4 in `universal_pe_model.py`  
**Rule used throughout:** no constant, exponent, or functional branch was refitted.

## 1. Short verdict

The frozen formula is **genuinely general inside canonical, attached, near-equilibrium wall turbulence**, but it is **not yet a universal closure for all wall-bounded flows**.

- On 14 independent DNS applications spanning channels, plane Couette flow, pipes, and open-channel flow, the frozen scores are
  \[
  R^2 = 0.934\text{--}0.999,\qquad \text{mean}=0.984,\qquad \text{median}=0.993.
  \]
- Reynolds-number extrapolation works well:
  - channel \(Re_\tau=10049\): \(R^2=0.991\);
  - pipe \(Re_\tau=5193\): \(R^2=0.966\);
  - Couette \(Re_\tau=2013\): \(R^2=0.934\).
- A new flow class, turbulent open channel at \(Re_\tau=2008\), gives \(R^2=0.994\), with dissipation approximated by enstrophy because no budget file is published.
- An independent zero-pressure-gradient boundary layer transfers only moderately: \(R^2=0.875\text{--}0.901\). The shape is right, but the model is systematically high near the peak and in the outer layer.
- Mild/strong adverse-pressure-gradient layers and transpired channels fail decisively. The main reason is now clear: the term proportional to the mean wall-normal velocity \(V^+\) represents **zero-pressure-gradient entrainment**, not general mean convection. It becomes far too large when \(V^+\) is produced by sink-flow pressure gradient, wall blowing, or a collapsing local \(u_\tau\).

The best description is therefore:

> **U4 is a semi-universal equilibrium closure. Its inner-peak, total-stress-wake, geometry, and core-import structure transfer across canonical flows, but its growth term and its \(0\le\tau\le1\) stress description do not cover pressure-gradient history, separation, or wall transpiration.**

---

## 2. Test protocol

The prediction is

\[
\widehat{P/\varepsilon}
 = B(y^+,Re_\tau,\tau_p)\,
   W_\tau(\tau)\,
   W_{\rm core}(y^+,\eta,\tau)\,
   W_{\rm geo}(\eta,m)
 + G(V^+,Re_\tau,\eta,\tau),
\]

with the exact frozen implementation in `universal_pe_model.py`. The inputs are \(y^+\), \(\eta=y/\delta\), \(Re_\tau\), the total-stress profile \(\tau(\eta)\), the mean wall-normal velocity \(V^+(\eta)\), and the geometry index \(m\) (\(0\) planar, \(1\) pipe).

All scores below use the same mask:

\[
y^+\ge 0.05,\qquad \eta\le 1.
\]

The frozen implementation clips \(\tau\) to \([0,1]\). This is part of the model being tested and becomes important in adverse-pressure-gradient and transpired flows, where the total stress can exceed the local wall stress.

For several failure cases I also report a **diagnostic** score obtained by setting the input \(V^+=0\) while retaining every frozen constant. This is not an alternative fitted model. It only separates failure of the growth term from failure of the remaining base structure.

The complete rerunnable evaluation is:

```bash
python3 independent_evaluation.py
```

It writes `independent_results.csv`, `independent_profiles.pdf`, and `independent_profiles.png`.

---

## 3. Canonical independent flows

### 3.1 Scores

| Dataset | \(Re_\tau\) | Frozen \(R^2\) | DNS peak | Predicted peak |
|---|---:|---:|---:|---:|
| Hoyas/Oberlack channel | 10049 | **0.99106** | 1.716 | 1.775 |
| BPO channel | 183 | **0.99501** | 1.838 | 1.826 |
| BPO channel | 550 | **0.99872** | 1.749 | 1.790 |
| BPO channel | 999 | **0.99862** | 1.743 | 1.784 |
| BPO channel | 2022 | **0.99778** | 1.721 | 1.781 |
| BPO channel | 4079 | **0.98915** | 1.698 | 1.778 |
| FDY Couette | 132 | **0.99325** | 1.756 | 1.775 |
| FDY Couette | 177 | **0.99600** | 1.761 | 1.776 |
| FDY Couette | 244 | **0.99354** | 1.755 | 1.776 |
| FDY Couette | 553 | **0.94411** | 1.726 | 1.773 |
| FDY Couette budgets | 2013 | **0.93382** | 1.702 | 1.773 |
| Yao pipe | 549 | **0.98923** | 1.792 | 1.780 |
| Yao pipe | 5193 | **0.96625** | 1.747 | 1.776 |
| Yao open channel\(^*\) | 2008 | **0.99426** | 1.775 | 1.779 |

\(^*\)The open-channel file contains vorticity moments but no dissipation budget; \(\varepsilon^+\) was approximated by \(\omega_x'^2+\omega_y'^2+\omega_z'^2\). This is supporting evidence, not budget-grade proof.

For the channel at \(Re_\tau=10049\), using measured total stress instead of the analytic \(\tau=1-\eta\) gives \(R^2=0.99114\), essentially unchanged from \(0.99106\).

### 3.2 What transfers

Three pieces of physics transfer across independent codes and geometries:

1. **The near-wall/equal-stress peak.** Most independent peaks are captured within about \(0.02\)–\(0.08\). There is a small systematic tendency to overpredict the peak in several high-Reynolds-number datasets, indicating either a weak missing Reynolds-number trend or different dissipation conventions between DNS groups.
2. **The total-stress wake.** The same stress-controlled decline works in channels, pipes, and open channel. The open-channel result is important: there is no opposite wall or centreline, yet a stress that decreases to zero at the surface produces nearly the same \(P/\varepsilon\) shape.
3. **The pipe geometry factor.** It transfers to an independent pipe code, although it is slightly too strong in the \(Re_\tau=5193\) core.

### 3.3 Remaining canonical weaknesses

The core shape is not perfectly universal:

- FDY Couette at \(Re_\tau=553\): centre value \(0.689\) in DNS versus \(0.521\) predicted.
- FDY Couette at \(Re_\tau=2013\): the model is low in the log region but high by about \(0.12\)–\(0.14\) at \(\eta=0.65\)–\(0.80\), while the centre value is nearly correct.
- Yao pipe at \(Re_\tau=5193\): prediction is low by \(0.108\) at \(\eta=0.05\) and by \(0.142\) at \(\eta=0.50\).

Thus the core-import factor has the right qualitative role, but its precise \(\eta\)-shape and Reynolds-number development are less universal than the inner and stress-wake parts.

---

## 4. Independent boundary layers

The Kitsios datasets contain direct production and pseudo-dissipation budgets. For each station, \(u_\tau\) was obtained from the wall gradient, \(\delta_{99}\) from the mean profile, \(\tau\) from viscous plus Reynolds stress, and \(V^+\) from the stored mean wall-normal velocity.

### 4.1 Zero pressure gradient

| Station | \(Re_\tau\) | Frozen \(R^2\) | Diagnostic \(V^+=0\) |
|---|---:|---:|---:|
| st50 | 1181 | 0.8976 | 0.6554 |
| st200 | 1201 | 0.8745 | 0.6558 |
| st400 | 1224 | 0.8939 | 0.6694 |
| st1393 | 1315 | 0.9009 | 0.7314 |

The formula clearly transfers, but not at the \(0.99\) level found on the KTH training profiles. The DNS peak is \(1.708\)–\(1.718\), while the model gives about \(1.77\). Outer-layer predictions are high by roughly \(0.06\)–\(0.16\). This means part of the fitted boundary-layer growth/plateau behaviour encodes the KTH dataset and its budget conventions. The structure is portable, but this cross-code result should replace any claim that the frozen constants are exact for every ZPG simulation.

### 4.2 Mild adverse pressure gradient, \(\beta=1\)

| Station | \(Re_\tau\) | Frozen \(R^2\) | Diagnostic \(V^+=0\) |
|---|---:|---:|---:|
| st100 | 707 | −15.21 | 0.406 |
| st290 | 737 | −16.15 | 0.450 |
| st480 | 765 | −16.59 | 0.448 |
| st570 | 778 | −16.83 | 0.460 |

This is not a small calibration error. The model predicts \(P/\varepsilon\approx3.8\)–\(3.9\) near \(\eta=1\), whereas DNS gives about \(0.5\).

The input scales explain the failure:

- \(V^+\) at \(\eta=0.8\) is about \(0.20\), and at the edge about \(0.27\);
- the KTH ZPG training range is about \(0.049\)–\(0.067\) at its edge;
- total stress reaches \(\tau_{\max}\approx1.8\), but the frozen code clips it to \(1\).

Because the frozen growth term is linear in \(V^+\), a five-fold increase of edge \(V^+\) becomes a large spurious source. Switching \(V^+\) off diagnostically improves the score to only \(0.41\)–\(0.46\), so the growth term is the largest error but not the only missing physics. The APG layer also moves production outward: DNS rises to about \(1.15\) in the outer layer while the remaining base model declines.

### 4.3 Strong adverse pressure gradient, \(\beta=39\)

| Station | \(Re_\tau\) | Frozen \(R^2\) | Diagnostic \(V^+=0\) |
|---|---:|---:|---:|
| st200 | 1227 | −17.26 | −0.021 |
| st500 | 1231 | −23.12 | 0.009 |
| st800 | 1229 | −22.22 | 0.003 |
| st980 | 1202 | −19.00 | −0.020 |

At the verge of separation, the descriptor scaling itself changes character:

- \(V^+\) reaches \(4.6\)–\(4.8\) at \(\eta=1\);
- \(\tau_{\max}=18\)–\(27\) in local wall units;
- \(U_e^+=68\)–\(77\), because local \(u_\tau\) is very small;
- the near-wall \(P/\varepsilon\) peak collapses to \(0.81\)–\(0.93\), while U4 still predicts \(1.77\)–\(1.78\);
- production becomes negative in the far outer layer, so \(P/\varepsilon\) itself is negative there.

This regime needs pressure-gradient/history variables and a non-degenerate outer scaling. It cannot be repaired by changing one constant in the present formula.

---

## 5. Transpired Poiseuille flow

The Avsarkisov–Oberlack–Hoyas files use an average friction velocity based on both walls. I applied U4 separately from each wall using that wall's local \(u_\tau\), local \(y^+\), and local total-stress normalisation.

A data audit was necessary. In internally consistent FDY files, their dissipation column equals the enstrophy \(\omega_x'^2+\omega_y'^2+\omega_z'^2\) almost exactly. In the transpired files the labelled \(\varepsilon^+\) column has an incorrect global normalisation, while the vorticity columns retain the intended FDY dissipation definition. The evaluation therefore uses the enstrophy form, cross-checked at both walls.

### Blowing side

| Case (average-\(u_\tau\) label) | Local \(Re_\tau\) | Local \(v_0^+\) | Frozen \(R^2\) | Diagnostic \(V^+=0\) |
|---|---:|---:|---:|---:|
| 250, weak blowing | 195 | 0.066 | 0.174 | 0.918 |
| 480, stronger blowing | 220 | 0.235 | −12.83 | 0.540 |
| 850, weak blowing | 604 | 0.072 | −1.13 | 0.568 |

Local total stress reaches \(1.74\), \(4.85\), and \(2.07\), respectively, and is clipped by U4. For the weakest case, the \(V^+=0\) diagnostic is good, suggesting that the base stress structure can survive mild blowing when the ZPG-entrainment term does not misfire. For the other cases it falls to about \(0.54\)–\(0.57\), so transpiration changes the turbulence beyond simply adding the frozen growth term.

### Suction side

| Case | Local \(Re_\tau\) | Frozen \(R^2\) with \(\delta=h\) | Diagnostic \(V^+=0\) |
|---|---:|---:|---:|
| 250 | 292 | 0.369 | 0.414 |
| 480 | 642 | −0.900 | −0.885 |
| 850 | 1024 | 0.036 | 0.153 |

These suction-side applications are geometrically ill-posed with \(\delta=h\). The zero-total-stress point lies only \(0.432h\), \(0.107h\), and \(0.417h\) from the suction wall in the three cases. The channel is therefore not two symmetric \(h\)-thick wall layers. A future transpired-flow closure needs side-specific outer lengths based on the displaced stress-zero location, plus the wall mass-flux boundary condition as a distinct input.

---

## 6. Profile picture

![Frozen U4 on representative independent flows](independent_profiles.png)

The first two rows show the validated canonical behaviour and its remaining core-shape errors. The last row shows the decisive failure mode: in APG and transpired flow, the linear \(V^+\) growth term rises far above the DNS instead of following the real outer-layer energy balance.

---

## 7. Validated domain

The frozen formula may be used with reasonable confidence when **all** of the following hold:

1. The flow is attached, smooth-wall, incompressible, and statistically two-dimensional in the mean.
2. It is a parallel equilibrium flow or a slowly developing ZPG TBL.
3. The total stress satisfies \(0\le\tau\le1\), without a substantial APG overshoot; normally it starts near \(1\) at the wall and decreases towards the centre/edge. Plane Couette is the prescribed special case \(\tau=1\).
4. \(V^+\) is zero at an impermeable wall and has an entrainment shape no larger than the ZPG range seen in training, approximately \(V^+\lesssim0.07\).
5. The outer length \(\delta\) is unambiguous: channel half-height, pipe radius, Couette half-gap, open-channel depth, or \(\delta_{99}\) for a ZPG TBL.
6. Local wall scaling is non-degenerate; the flow is not close to separation where \(u_\tau\to0\).
7. The Reynolds number lies within or close to the independently demonstrated range: channels to \(10049\), pipes to \(5193\), Couette flow to \(2013\), open channel at \(2008\), and ZPG TBL around \(1200\) in the independent test.

The present frozen formula should **not** be used for:

- adverse-pressure-gradient layers with stress overshoot or an outer production peak;
- incipient or actual separation;
- wall blowing/suction when \(V^+\) is an imposed transpiration velocity rather than entrainment;
- wing trailing-edge layers where local \(u_\tau\) collapses and the rotated-frame \(V^+\) becomes large;
- flows with negative production over a substantial part of the layer.

Rough-wall, compressible, rotating, stratified, and strongly three-dimensional flows remain **untested**, rather than proven invalid.

---

## 8. Physical conclusion

The independent tests separate the formula into two parts with different status.

### Likely physical and broadly transferable

- the equal-stress near-wall peak;
- the saturated log-layer crest at \(y_c\sim\sqrt{100Re_\tau}\);
- decline controlled by the actual total-stress profile;
- the planar/axisymmetric geometry factor;
- a core-import reduction in constant-stress Couette-like regions, at least qualitatively.

These pieces survive changes of DNS code, geometry, Reynolds number, and even replacement of a centreline by a free surface.

### Not yet universal

- the term \(G\propto V^+\). Real mean convection is
  \[
  C_k=-\left(U\frac{\partial k}{\partial x}+V\frac{\partial k}{\partial y}\right),
  \]
  so its effect cannot generally be inferred from local \(V^+\) alone. U4's term is a useful ZPG-entrainment surrogate, not a general convection closure.
- the restriction that \(\tau\) behaves like a number between zero and one;
- absence of pressure-gradient strength, streamwise history, and an APG outer-production mechanism;
- absence of a separate wall-transpiration boundary-condition variable;
- exact shape of the high-Reynolds-number Couette/pipe core.

So the honest final statement is:

> **U4 is a general physical closure for canonical attached equilibrium wall layers described by \((y^+,\eta,Re_\tau,\tau,V^+,m)\) within the input ranges above. It is not yet a universal wall-turbulence closure.**

---

## 9. Appendix: NACA4412 wing LES

The WingData NACA4412 stations were evaluated but are not included in the headline DNS verdict. They are well-resolved LES in a wall-tangential/wall-normal rotating frame, with only 25–34 points inside \(\eta\le1\), and budget conventions that do not map one-to-one onto the DNS budgets used elsewhere.

| Station | \(\beta\) | \(Re_\tau\) | Frozen \(R^2\) | Diagnostic \(V^+=0\) |
|---|---:|---:|---:|---:|
| st10 | 0.1 | 364 | 0.370 | −0.363 |
| st25 | 1.0 | 575 | −0.392 | −0.313 |
| st33 | 2.0 | 674 | −3.994 | −0.278 |
| st39 | 4.6 | 705 | −22.06 | −0.564 |

The trend again exposes the \(V^+\)/local-\(u_\tau\) failure as the trailing edge is approached, but the LES \(P/\varepsilon\) peaks (\(2.02\)–\(2.18\)) also differ systematically from the DNS sets. These rows are useful as a warning, not as a clean quantitative DNS test.

---

## 10. Files and provenance

### Deliverables

- `independent_evaluation.py` — complete frozen evaluation;
- `independent_results.csv` — all 36 scored rows;
- `independent_profiles.pdf` / `independent_profiles.png` — representative profiles;
- `Independent_PE_report.md` — this report.

### Independent data groups

- Hoyas/Oberlack channel \(Re_\tau=10049\), TUdatalib component budgets;
- Bernardini–Pirozzoli–Orlandi channel TKE budgets, \(Re_\tau=180\)–\(4079\);
- FDY TU Darmstadt plane Couette profiles and component budgets;
- Yao, Texas Data Repository pipe TKE budgets at \(Re_\tau\simeq549,5193\);
- Yao–Chen–Hussain open-channel statistics at \(Re_\tau\simeq2008\);
- Kitsios et al. ZPG, \(\beta=1\), and \(\beta=39\) TBL statistics and TKE budgets;
- Avsarkisov–Oberlack–Hoyas transpired Poiseuille profiles;
- Vinuesa et al. WingData NACA4412 well-resolved LES (appendix only).

No independent profile was used to adjust the U4 constants.
