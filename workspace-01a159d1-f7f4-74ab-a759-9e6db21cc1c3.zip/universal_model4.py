#!/usr/bin/env python3
"""
Universal physics-descriptor model for P/eps (U4).

One shared functional form for channels, pipes, ZPG TBLs and plane Couette flow.
Per-profile inputs (physical descriptors only):
  Re_tau, y+, eta=y/delta, total-stress profile tau(eta),
  mean wall-normal velocity V+(eta) (0 in parallel flows),
  geometry exponent m (0 planar, 1 axisymmetric pipe).

Structure:
  tau_p   = tau(y+ = 12)
  eps_pk  = E0 * tau_p^rp                      (dissipation at production peak)
  p_peak  = tau_p^2 / (4 eps_pk)               (equal-stress production bound)
  B       = F_in(y+; p_peak) + Ec(Re) L(y+; yc=sqrt(100 Re), w)
            Ec(Re) = Einf * (1 - sqrt(150/Re))_+   (log-layer extent, saturating)
  W_tau   = tanh^2(a tau)/tanh^2(a)            (stress-controlled wake)
  W_core  = 1 - cc tanh^2(y+/300) eta^2 tau^2  (constant-stress core import)
  W_geo   = 1/(1 + m eta/4)                    (axisymmetric collection, prescribed)
  G       = G0 V+ (lnRe/ln1000)^rg eta^pg tanh^2(a tau^qg)  (growth/entrainment)
  pe_hat  = B * W_tau * W_core * W_geo + G

Inner core F_in (shared, refitted with everything else):
  Gg = tanh^3(a1 y+ + a2 y+^2),  T = tanh(bwave y+)
  F_in = Gg [1 - T^5(1-T^2) + c1 y+^2 exp(-bexp y+)],  c1 set so max F_in = p_peak.
"""
import numpy as np
from scipy.optimize import least_squares
from universal_descriptors import augment_profiles

LN1000 = np.log(1000.0)
PARAM_NAMES = ["a1","a2","bexp","bwave","E0","rp","Einf","wbump","a","cc","G0","rg","pg","qg"]
X0 = np.array([0.16234303, 0.00596653, 0.20161904, 0.02065071,
               0.14187, 2.667, 0.12, 0.55, 3.9, 0.50, 11.9, 2.0, 0.5, 0.5])
LO = np.array([0.05, 0.0, 0.05, 0.005, 0.10, 0.0, 0.0, 0.30, 0.5, 0.0, 0.0, -2.0, -1.0, 0.05])
HI = np.array([0.30, 0.02, 0.40, 0.050, 0.20, 5.0, 0.25, 0.80, 10.0, 0.95, 60.0, 5.0, 3.0, 2.0])
IDX_CC = 9
IDX_GROWTH = slice(10, 14)

def F_in(yp, c1, a1, a2, bexp, bwave):
    yp = np.maximum(np.asarray(yp, dtype=float), 1e-12)
    Gg = np.tanh(a1 * yp + a2 * yp**2) ** 3
    T = np.tanh(bwave * yp)
    return Gg * (1.0 - T**5 * (1.0 - T**2) + c1 * yp**2 * np.exp(-bexp * yp))

def c1_for_peak(ppeak, a1, a2, bexp, bwave):
    ypg = np.linspace(8.0, 16.0, 400)
    lo, hi = 0.005, 0.5
    for _ in range(50):
        mid = 0.5 * (lo + hi)
        if F_in(ypg, mid, a1, a2, bexp, bwave).max() < ppeak:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)

def Lbump(yp, yc, w):
    yp = np.maximum(np.asarray(yp, dtype=float), 1e-12)
    return np.exp(-0.5 * (np.log(yp / yc) / w) ** 2)

def Ec_of_Re(Re, Einf, R0=150.0):
    return Einf * max(0.0, 1.0 - np.sqrt(R0 / Re))

def tau_at_yp(p, ytarget=12.0):
    return float(np.interp(ytarget / p["re_tau"], p["eta"], p["tau"]))

def predict(p, x):
    a1, a2, bexp, bwave, E0, rp, Einf, wbump, a, cc, G0, rg, pg, qg = x
    Re = p["re_tau"]; lnRe = np.log(Re)
    tau_p = tau_at_yp(p, 12.0)
    eps_pk = E0 * max(tau_p, 1e-9) ** rp
    ppeak = tau_p**2 / (4 * eps_pk)
    F0 = F_in(p["yp"], c1_for_peak(ppeak, a1, a2, bexp, bwave), a1, a2, bexp, bwave)
    yc = np.sqrt(100.0 * Re)
    B = F0 + Ec_of_Re(Re, Einf) * Lbump(p["yp"], yc, wbump)
    eta_c = np.clip(p["eta"], 0, 1.05)
    tau = np.clip(p["tau"], 0, 1)
    Wtau = np.tanh(a * tau) ** 2 / np.tanh(a) ** 2
    Wcore = 1 - cc * np.tanh(p["yp"] / 300.0) ** 2 * (eta_c ** 2) * (tau ** 2)
    Wgeo = 1.0 / (1.0 + p["mgeo"] * eta_c / 4.0)
    edge = np.tanh(a * (tau ** qg)) ** 2
    G = G0 * p["Vmean"] * (lnRe / LN1000) ** rg * (eta_c ** pg) * edge
    return B * Wtau * np.clip(Wcore, 0, None) * Wgeo + G

def mask_of(p, eta_max=1.05):
    return (p["eta"] <= eta_max) & (p["yp"] >= 0.05)

def r2(p, pred, eta_max=1.05):
    m = mask_of(p, eta_max); pe = p["pe"]
    return 1 - np.sum((pred[m] - pe[m]) ** 2) / np.sum((pe[m] - pe[m].mean()) ** 2)

def fit(train, x0=X0, freeze_growth=False, freeze_cc=False, eta_max=1.05):
    free = np.ones(len(x0), dtype=bool)
    if freeze_growth:
        free[IDX_GROWTH] = False
    if freeze_cc:
        free[IDX_CC] = False
    xf = x0.copy()
    def resid(z):
        x = xf.copy(); x[free] = z
        out = []
        for p in train:
            pr = predict(p, x)
            m = mask_of(p, eta_max)
            out.append((pr[m] - p["pe"][m]) / np.sqrt(m.sum()))
        return np.concatenate(out)
    res = least_squares(resid, x0[free], bounds=(LO[free], HI[free]),
                        max_nfev=4000, ftol=1e-12, xtol=1e-12)
    x = xf.copy(); x[free] = res.x
    return x, res

def evaluate(profs, x, eta_max=1.05):
    return {p["id"]: r2(p, predict(p, x), eta_max) for p in profs}

def add_groups(profs):
    for p in profs:
        p["group"] = "Channel" if p["family"] in ("LM","UPM") else {"KTH":"TBL","Pipe":"Pipe","Cou":"Couette"}[p["family"]]
    return profs

if __name__ == "__main__":
    profs = add_groups(augment_profiles())
    x, res = fit(profs)
    print("ALL-DATA FIT (U4)")
    for n, v in zip(PARAM_NAMES, x):
        print(f"  {n:6s} = {v:.6g}")
    scores = evaluate(profs, x)
    for p in profs:
        print(f"{p['id']:10s} {p['group']:8s} R2={scores[p['id']]:.5f}")
    vals = np.array(list(scores.values()))
    print(f"mean={vals.mean():.5f} median={np.median(vals):.5f} min={vals.min():.5f}")
    for g in ["Channel","Pipe","TBL","Couette"]:
        s = [scores[p["id"]] for p in profs if p["group"] == g]
        print(f"{g:8s} mean={np.mean(s):.5f} min={np.min(s):.5f}")
    np.save("/home/user/universal_u4_params.npy", x)
