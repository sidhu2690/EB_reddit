#!/usr/bin/env python3
import numpy as np
from universal_descriptors import augment_profiles
import universal_model4 as um

profs = um.add_groups(augment_profiles())
results = {}
for held in ["Channel","Pipe","TBL","Couette"]:
    train = [p for p in profs if p["group"] != held]
    test = [p for p in profs if p["group"] == held]
    # Priors frozen only where the held-out family is the sole carrier of that mechanism:
    #  - TBL held: growth (entrainment) coefficients stay at physics prior in X0.
    #  - Couette held: constant-stress core-import fraction cc stays at prior 1/2.
    freeze_growth = (held == "TBL")
    freeze_cc = (held == "Couette")
    x, res = um.fit(train, freeze_growth=freeze_growth, freeze_cc=freeze_cc)
    tr = um.evaluate(train, x); te = um.evaluate(test, x)
    results[held] = (x, te)
    print(f"\nHELD {held}  freeze_growth={freeze_growth} freeze_cc={freeze_cc}")
    print("  params:", {n: round(float(v),4) for n,v in zip(um.PARAM_NAMES, x)})
    print(f"  train mean={np.mean(list(tr.values())):.5f} min={np.min(list(tr.values())):.5f}")
    print(f"  TEST  mean={np.mean(list(te.values())):.5f} min={np.min(list(te.values())):.5f}")
    for p in test:
        print(f"   {p['id']:10s} R2={te[p['id']]:.5f}")
print("\nLOFO SUMMARY")
for held,(x,te) in results.items():
    print(f"{held:8s} mean={np.mean(list(te.values())):.5f} min={np.min(list(te.values())):.5f}")
