#!/usr/bin/env python3
"""
SEMBAN-B final: physics-mechanism general closure + cross-check of existing models
on all 26 DNS budget profiles.

Structure (each term = one measured budget mechanism):
  Channel/UPM :  P/eps = [F_in0(y+) + E_c(Re)*L(y+; y_c)] * W_ch(eta)
  TBL (KTH)   :  P/eps =  F_in0(y+)            * W_tbl(eta) + E_t*Pi(eta)      [growth-convection plateau]
  Pipe        :  P/eps = [F_in0(y+) + E_p*L(y+)] * W_pipe(eta)                 [axisymmetric collection]
  Couette     :  P/eps = [F_in0(y+) + E_c*L(y+)] * W_cou(eta)                  [no wake zero: tau_tot=1]
F_in0: universal inner core (LM{1000,5200}-frozen). Channel crest laws E_c(Re), y_c(Re)
refrozen on LM{1000,5200} with the multiplicative structure. Family constants identified
once (TBL: KTH_4060; Pipe: Pipe_550; Couette: Cou_220+Cou_500) and validated on the rest.
"""
import numpy as np
from scipy.optimize import least_squares
from budget_loader import load_all_budgets

A1, A2, C1, B1, B2 = 0.16234303, 0.00596653, 0.06272513, 0.20161904, 0.02065071

def F_in0(yp, c1=C1):
    G = np.tanh(A1*yp + A2*yp**2)**3
    T = np.tanh(B2*yp)
    return G*(1.0 - T**5*(1.0 - T**2) + c1*yp**2*np.exp(-B1*yp))

def peak_of_c1(c1):
    ypg = np.linspace(8.0, 16.0, 400)
    return F_in0(ypg, c1).max()

_c1_cache = {}
def c1_for_peak(pk):
    key = round(pk, 6)
    if key in _c1_cache: return _c1_cache[key]
    lo, hi = 0.005, 0.5
    for _ in range(50):
        mid = 0.5*(lo+hi)
        if peak_of_c1(mid) < pk: lo = mid
        else: hi = mid
    _c1_cache[key] = 0.5*(lo+hi)
    return _c1_cache[key]

# ---------------- channel frozen laws (LM {1000, 5200})
def eps_w_ch(Re): return 0.4886 - 1.641/np.log(Re)
def peak_ch(Re):  return 2.066 - 1.135*eps_w_ch(Re)
G0_CH, G1_CH = 0.07759239, 3.92368480
def W_ch(eta): return (1.0 - G0_CH*eta)*np.tanh(G1_CH*(1.0-eta))**2

# crest law (refrozen below at runtime on LM{1000,5200})
EC_SLOPE, EC_INT, YC_SLOPE, YC_INT = 0.0202, -0.063, 61.8, -202.0
def Ec_ch(Re): return max(0.0, EC_SLOPE*np.log(Re) + EC_INT)
def yc_ch(Re): return YC_SLOPE*np.log(Re) + YC_INT
def Lbump(yp, yc):
    return np.exp(-0.5*((np.log(np.maximum(yp,1e-6)) - np.log(yc))/0.55)**2)

def predict(yp, eta, Re, fam, P):
    pk = P["peak"](Re) if callable(P["peak"]) else P["peak"]
    Fin = F_in0(yp, c1_for_peak(pk))
    if fam == "ch":
        return (Fin + Ec_ch(Re)*Lbump(yp, yc_ch(Re)))*W_ch(eta)
    if fam == "tbl":
        W = 1.0/(1.0+np.exp((eta-P["e0"])/P["we"]))*(1.0+np.exp(-P["e0"]/P["we"]))
        cr = P["Et"]*np.exp(-0.5*((eta-P["etc"])/P["wt"])**2)
        return Fin*W + cr
    if fam == "pipe":
        W = (1.0 - P["g0p"]*eta)*np.tanh(P["g1p"]*(1.0-eta))**2
        return (Fin + P["Ep"]*Lbump(yp, P["ycp"]))*W
    if fam == "cou":
        W = 1.0 - P["kcore"]*np.tanh(eta/P["etc2"])**2
        return (Fin + P["Ec"]*Lbump(yp, P["ycc"]))*W
    raise ValueError(fam)

def r2_of(pred, pe): return 1.0 - np.sum((pred-pe)**2)/np.sum((pe-pe.mean())**2)

def fit_on(profs, fam, P, keys):
    def resid(x):
        Q = dict(P); Q.update(dict(zip(keys, x)))
        return np.concatenate([predict(p["yp"], p["eta"], p["re_tau"], fam, Q) - p["P"]/p["eps"] for p in profs])
    r = least_squares(resid, [P[k] for k in keys], method="trf", max_nfev=20000, ftol=1e-14, xtol=1e-14)
    Q = dict(P); Q.update(dict(zip(keys, r.x)))
    return Q

def fit_ch_crest_laws(profs):
    """Refreeze channel crest laws E_c(Re)=s*lnRe+i and y_c(Re)=a*lnRe+b on LM{1000,5200}."""
    global EC_SLOPE, EC_INT, YC_SLOPE, YC_INT
    def resid(x):
        global EC_SLOPE, EC_INT, YC_SLOPE, YC_INT
        EC_SLOPE, EC_INT, YC_SLOPE, YC_INT = x
        out = []
        for p in profs:
            out.append(predict(p["yp"], p["eta"], p["re_tau"], "ch", dict(peak=peak_ch)) - p["P"]/p["eps"])
        return np.concatenate(out)
    r = least_squares(resid, [EC_SLOPE, EC_INT, YC_SLOPE, YC_INT], method="trf", max_nfev=20000, ftol=1e-14, xtol=1e-14)
    EC_SLOPE, EC_INT, YC_SLOPE, YC_INT = r.x
    return r.x

if __name__ == "__main__":
    profs = load_all_budgets()
    by = {p["id"]: p for p in profs}
    fam_of = {"LM":"ch", "UPM":"ch", "KTH":"tbl", "Pipe":"pipe", "Cou":"cou"}

    law = fit_ch_crest_laws([by["LM_1000"], by["LM_5200"]])
    print(f"Channel crest laws refrozen on LM{{1000,5200}}: E_c = {law[0]:.4f} lnRe {law[1]:+.3f}, y_c = {law[2]:.1f} lnRe {law[3]:+.1f}")

    P = {"ch": dict(peak=peak_ch)}
    P["tbl"] = fit_on([by["KTH_4060"]], "tbl",
                      dict(peak=1.758, e0=0.93, we=0.035, Et=0.17, etc=0.58, wt=0.28),
                      ["e0","we","Et","etc","wt"])
    print("TBL (KTH_4060):", {k: round(float(v),4) for k,v in P["tbl"].items()})
    P["pipe"] = fit_on([by["Pipe_550"]], "pipe",
                       dict(peak=1.785, g0p=0.10, g1p=4.2, Ep=0.05, ycp=230.0),
                       ["g0p","g1p","Ep","ycp"])
    print("Pipe (Pipe_550):", {k: round(float(v),4) for k,v in P["pipe"].items()})
    P["cou"] = fit_on([by["Cou_220"], by["Cou_500"]], "cou",
                      dict(peak=1.745, kcore=0.15, etc2=0.35, Ec=0.10, ycc=190.0),
                      ["kcore","etc2","Ec","ycc"])
    print("Couette (Cou_220+500):", {k: round(float(v),4) for k,v in P["cou"].items()})

    print()
    print("="*100)
    print("SEMBAN-B FROZEN ON ALL 26 DNS BUDGET PROFILES")
    print("="*100)
    r2s = []
    print(f"{'id':10s} {'Re':>6s} {'fam':4s} {'R2':>8s} {'pk_err':>7s} {'tr_err':>7s} {'cr_err':>7s} {'outer':>7s}")
    for p in profs:
        fam = fam_of[p["family"]]
        pred = predict(p["yp"], p["eta"], p["re_tau"], fam, P[fam])
        pe = p["P"]/p["eps"]
        r2 = r2_of(pred, pe); r2s.append(r2)
        m = p["yp"] < 30
        pk_e = pred[m].max() - pe[m].max()
        m2 = (p["yp"] >= 30) & (p["yp"] <= 120)
        tr_e = pred[m2].min() - pe[m2].min() if m2.sum() > 2 else np.nan
        m3 = (p["yp"] >= 130) & (p["eta"] <= 0.75)
        cr_e = (pred[m3].max() - pe[m3].max()) if m3.sum() > 2 else np.nan
        m4 = p["eta"] >= 0.5
        w_e = np.median(np.abs(pred[m4]-pe[m4])) if m4.sum() > 2 else np.nan
        print(f"{p['id']:10s} {p['re_tau']:6.0f} {fam:4s} {r2:8.5f} {pk_e:+7.3f} {tr_e:+7.3f} {cr_e:+7.3f} {w_e:7.3f}")
    print(f"\nSEMBAN-B: mean R2 = {np.mean(r2s):.5f}, median = {np.median(r2s):.5f}, min = {np.min(r2s):.5f}")
