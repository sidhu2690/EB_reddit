#!/usr/bin/env python3
"""
Augment the 26 DNS TKE-budget profiles with physical descriptors:
  tau   : total stress (mean viscous + Reynolds shear stress), wall units
  S     : mean shear dU+/dy+ (where mean profiles are available, else nan)
  tauR  : Reynolds shear stress -<u'v'>+ (where available, else nan)
  Vmean : mean wall-normal velocity V+ (nonzero only for developing TBL)
  alpha : imposed total-stress/pressure-gradient coefficient
            1 = pressure-driven internal flow, 0 = zero-pressure-gradient
  mgeo  : geometry exponent in wall-normal divergence (0 planar, 1 axisymmetric pipe)
  Ve    : edge entrainment velocity V+(eta~1), a streamwise-development scalar
"""
import numpy as np
from budget_loader import load_all_budgets

LM_TAG = {"LM_180":"0180","LM_550":"0550","LM_1000":"1000","LM_2000":"2000","LM_5200":"5200"}
KTH_TAG = {"KTH_0670":"0670","KTH_1000":"1000","KTH_1410":"1410","KTH_2000":"2000",
           "KTH_2540":"2540","KTH_3030":"3030","KTH_3270":"3270","KTH_3630":"3630",
           "KTH_3970":"3970","KTH_4060":"4060"}
PIPE_TAG = {"Pipe_180":"180","Pipe_360":"360","Pipe_550":"550","Pipe_1000":"1000"}

def _load_numeric(path, mincols=8):
    rows = []
    with open(path) as f:
        for line in f:
            if line.lstrip().startswith("%"):
                continue
            parts = line.replace("\t", " ").split()
            if len(parts) >= mincols:
                try:
                    rows.append([float(v) for v in parts[:mincols+2]])
                except ValueError:
                    continue
    return np.array(rows)

def _interp(x, xp, fp):
    o = np.argsort(xp)
    return np.interp(x, xp[o], fp[o], left=fp[o][0], right=fp[o][-1])

def augment_profiles():
    profs = load_all_budgets()
    for p in profs:
        eta, yp = p["eta"], p["yp"]
        p["pe"] = p["P"]/p["eps"]
        p["S"] = np.full_like(eta, np.nan, dtype=float)
        p["tauR"] = np.full_like(eta, np.nan, dtype=float)
        p["Vmean"] = np.zeros_like(eta, dtype=float)
        fam = p["family"]
        if fam in ("LM","UPM","Pipe"):
            p["alpha"] = 1.0
        else:
            p["alpha"] = 0.0
        p["mgeo"] = 1.0 if fam == "Pipe" else 0.0

        if p["id"] in LM_TAG:
            tag = LM_TAG[p["id"]]
            mean = np.loadtxt(f"/home/user/dns_data/LM_Channel_{tag}_mean_prof.dat", comments="%")
            fluc = np.loadtxt(f"/home/user/dns_data/LM_Channel_{tag}_vel_fluc_prof.dat", comments="%")
            p["S"] = _interp(yp, mean[:,1], mean[:,3])
            p["tauR"] = _interp(yp, fluc[:,1], -fluc[:,5])
            p["tau_meas"] = p["S"] + p["tauR"]
            p["tau"] = 1.0 - eta
        elif fam == "UPM":
            p["tau_meas"] = 1.0 - eta
            p["tau"] = 1.0 - eta
        elif fam == "Cou":
            p["tau_meas"] = np.ones_like(eta)
            p["tau"] = np.ones_like(eta)
        elif p["id"] in KTH_TAG:
            tag = KTH_TAG[p["id"]]
            vel = np.loadtxt(f"/home/user/dns_data/kth_tbl/vel_{tag}_dns.prof", comments="%")
            # cols: eta, y+, U+, urms, vrms, wrms, uv+, prms, pu, pv, S(u), F(u), dU+/dy+, V+, ...
            p["S"] = _interp(eta, vel[:,0], vel[:,12])
            p["tauR"] = _interp(eta, vel[:,0], -vel[:,6])
            p["Vmean"] = _interp(eta, vel[:,0], vel[:,13])
            p["tau_meas"] = p["S"] + p["tauR"]
            p["tau"] = p["tau_meas"]
        elif p["id"] in PIPE_TAG:
            tag = PIPE_TAG[p["id"]]
            d = _load_numeric(f"/home/user/dns_data/el_khoury_pipe/{tag}_Re_1.dat", mincols=9)
            # cols: (1-r)=y/R, y+, Uz+, Uz/Ub, ur_rms, ut_rms, uz_rms, uzur+, dUzdr+
            # dUz/dr is wrt r (positive from axis); dU/dy = -dU/dr.
            p["S"] = _interp(eta, d[:,0], -d[:,8])
            p["tauR"] = _interp(eta, d[:,0], d[:,7])  # <uz ur>; ur is outward, so -<uz uy> = +<uz ur>
            p["tau_meas"] = p["S"] + p["tauR"]
            p["tau"] = 1.0 - eta
        else:
            p["tau_meas"] = np.ones_like(eta)
            p["tau"] = np.ones_like(eta)

        # Edge entrainment/developmentscalar
        if fam == "KTH":
            i = np.argmin(np.abs(eta - 1.0))
            p["Ve"] = float(p["Vmean"][i])
        else:
            p["Ve"] = 0.0
        # local total-stress slope (outer coordinate), smoothed by gradient on sorted eta
        o = np.argsort(eta)
        sig = np.zeros_like(eta)
        sig[o] = -np.gradient(p["tau"][o], eta[o])
        p["sigma"] = sig
    return profs

if __name__ == "__main__":
    profs = augment_profiles()
    for p in profs:
        m = (p["eta"] >= 0.15) & (p["eta"] <= 0.98) & np.isfinite(p["S"])
        tau_err = np.max(np.abs(p["tau_meas"][m] - p["tau"][m])) if m.sum() > 3 else np.nan
        print(f"{p['id']:10s} {p['family']:4s} Re={p['re_tau']:7.1f} alpha={p['alpha']:.0f} m={p['mgeo']:.0f} "
              f"Ve={p['Ve']:.4f} tau(0.5)={np.interp(0.5,p['eta'],p['tau']):.3f} tau(0.8)={np.interp(0.8,p['eta'],p['tau']):.3f} "
              f"max|tau_meas-tau_model|={tau_err:.4f}")
