#!/usr/bin/env python3
"""
Universal physics-descriptor candidate for P/eps (U3, constrained).

Inputs per profile: Re_tau, y+, eta, total stress tau(eta), mean wall-normal
velocity V+(eta), geometry exponent m (0 planar, 1 pipe).

Structure (one shared form, no family branches):
  eps_pk = E0 * tau_p^rp,  tau_p = tau(y+=12)
  p_peak = tau_p^2/(4 eps_pk)
  B      = F_in(y+; p_peak) + Ec(Re) * L(y+; yc=Cc*sqrt(Re))
  What   = W_tau(tau) * W_core(y+,eta,tau) * W_geo(eta,m)
  pe_hat = B * What + G(V+,Re,eta,tau)
"""
import numpy as np
from scipy.optimize import least_squares, brentq
from universal_descriptors import augment_profiles

# Inner core constants (same frozen core as semban_b_final.py)
A1, A2, B1, B2 = 0.16234303, 0.00596653, 0.20161904, 0.02065071
LN1000 = np.log(1000.0)

def F_in(yp, c1):
    yp = np.maximum(np.asarray(yp, dtype=float), 1e-12)
    G = np.tanh(A1 * yp + A2 * yp**2) ** 3
    T = np.tanh(B2 * yp)
    return G * (1.0 - T**5 * (1.0 - T**2) + c1 * yp**2 * np.exp(-B1 * yp))

def c1_for_peak(ppeak):
    ypg = np.linspace(8.0, 16.0, 400)
    lo, hi = 0.005, 0.5
    for _ in range(50):
        mid = 0.5 * (lo + hi)
        if F_in(ypg, mid).max() < ppeak:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)

def Lbump(yp, yc, w=0.55):
    yp = np.maximum(np.asarray(yp, dtype=float), 1e-12)
    return np.exp(-0.5 * (np.log(yp / yc) / w) ** 2)

def Ec_of_Re(Re, Einf, R0=150.0):
    # Saturating log-layer extent factor: no crest below Re~150 (no log layer),
    # tends to Einf at large Re. Bounded -> safe Re extrapolation.
    return Einf * max(0.0, 1.0 - np.sqrt(R0 / Re))

PARAM_NAMES = ["E0","rp","Einf","Cc","wbump","a","cc","G0","rg","pg","qg"]
X0 = np.array([0.14187, 2.667, 0.12, 6.5, 0.55, 3.8, 0.50, 11.9, 2.0, 0.5, 0.5])
LO = np.array([0.10, 0.0, 0.0, 4.0, 0.30, 0.5, 0.0, 0.0, -2.0, -1.0, 0.05])
HI = np.array([0.20, 5.0, 0.25, 10.0, 0.80, 10.0, 0.95, 60.0, 5.0, 3.0, 2.0])

def tau_at_yp(p, ytarget=12.0):
    eta_t = ytarget / p["re_tau"]
    return float(np.interp(eta_t, p["eta"], p["tau"]))

def predict(p, x, F0cache=None):
    E0, rp, Einf, Cc, wbump, a, cc, G0, rg, pg, qg = x
    Re = p["re_tau"]; lnRe = np.log(Re)
    if F0cache is not None and p["id"] in F0cache:
        F0 = F0cache[p["id"]]
    else:
        tau_p = tau_at_yp(p, 12.0)
        eps_pk = E0 * max(tau_p, 1e-9) ** rp
        ppeak = tau_p**2 / (4 * eps_pk)
        F0 = F_in(p["yp"], c1_for_peak(ppeak))
        if F0cache is not None:
            F0cache[p["id"]] = F0
    yc = Cc * np.sqrt(Re)
    B = F0 + Ec_of_Re(Re, Einf) * Lbump(p["yp"], yc, wbump)
    eta = np.clip(p["eta"], 0, None)
    eta_c = np.clip(eta, 0, 1.05)
    tau = np.clip(p["tau"], 0, 1)
    Wtau = np.tanh(a * tau) ** 2 / np.tanh(a) ** 2
    Wcore = 1 - cc * np.tanh(p["yp"] / 300.0) ** 2 * (eta_c ** 2) * (tau ** 2)
    Wgeo = 1.0 / (1.0 + p["mgeo"] * eta_c / 4.0)
    edge = np.tanh(a * (tau ** qg)) ** 2
    G = G0 * p["Vmean"] * (lnRe / LN1000) ** rg * (eta_c ** pg) * edge
    return B * Wtau * np.clip(Wcore, 0, None) * Wgeo + G

def mask_of(p, eta_max=1.05):
    return (p["eta"] <= eta_max) & (p["yp"] >= 0.05)

def r2(p, pred, eta_max=1.05):
    m = mask_of(p, eta_max); pe = p["pe"]
    return 1 - np.sum((pred[m] - pe[m]) ** 2) / np.sum((pe[m] - pe[m].mean()) ** 2)

def fit(train, x0=X0, freeze_growth=False, eta_max=1.05, freeze_cc=False):
    # F0 depends on (E0, rp) only through ppeak; cache per (E0,rp) rounded is unsafe,
    # so precompute nothing: c1_for_peak is cheap enough per profile per iteration? It
    # calls brentq on 400-pt grid; acceptable for 26 profiles.
    free = np.ones(len(x0), dtype=bool)
    if freeze_growth:
        free[7:] = False  # G0, rg, pg, qg stay at prior x0 values
    if freeze_cc:
        free[6] = False  # cc stays at prior core-import fraction 1/2
    xf = x0.copy()
    def resid(z):
        x = xf.copy(); x[free] = z
        out = []
        cache = {}
        for p in train:
            pr = predict(p, x, cache)
            m = mask_of(p, eta_max)
            out.append((pr[m] - p["pe"][m]) / np.sqrt(m.sum()))
        return np.concatenate(out)
    res = least_squares(resid, x0[free], bounds=(LO[free], HI[free]),
                        max_nfev=4000, ftol=1e-12, xtol=1e-12)
    x = xf.copy(); x[free] = res.x
    return x, res

def evaluate(profs, x, eta_max=1.05):
    cache = {}
    scores = {}
    for p in profs:
        scores[p["id"]] = r2(p, predict(p, x, cache), eta_max)
    return scores

if __name__ == "__main__":
    profs = augment_profiles()
    for p in profs:
        p["group"] = "Channel" if p["family"] in ("LM","UPM") else {"KTH":"TBL","Pipe":"Pipe","Cou":"Couette"}[p["family"]]
    x, res = fit(profs)
    print("ALL-DATA FIT")
    for n, v in zip(PARAM_NAMES, x):
        print(f"  {n:6s} = {v:.6g}")
    scores = evaluate(profs, x)
    for p in profs:
        print(f"{p['id']:10s} {p['group']:8s} R2={scores[p['id']]:.5f}")
    vals = np.array(list(scores.values()))
    print(f"mean={vals.mean():.5f} median={np.median(vals):.5f} min={vals.min():.5f}")
    for g in ["Channel","Pipe","TBL","Couette"]:
        s = [scores[p["id"]] for p in profs if p["group"] == g]
        print(f"{g:8s} mean={np.mean(s):.5f} min={np.min(s):.5f}")
